from card import cards
from variable import *
from calculate import update_data
import random
import pygame

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


def playCardGreen(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/2-blocksize*2) and mouseY > (display_height/2-blocksize*1.65) and Board[BX+(BY*4)].card == False:
            if card == "SPG":
                SP("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTG":
                APT("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APG":
                AP("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCG":
                ADC("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKG":
                TANK("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFG":
                heavyFighter("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFG":
                lightFighter("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSG":
                ASS("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPG":
                SP("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTG":
                APT("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APG":
                AP("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCG":
                ADC("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKG":
                TANK("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFG":
                heavyFighter("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFG":
                lightFighter("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSG":
                ASS("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
    return False



class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "TANKG", 10, 1, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class luckyBlock(cards):
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "luckyBlock", 1, 0, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.425),
                          (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.425),
                          blocksize*0.15, blocksize*0.15), 4) # type: ignore
        drawText("?", text_font, (51, 255, 51), (display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4625), 
                 (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.425), screen)
        self.update(screen)

    def ability(self, enemy, turn):
        global P1Luck, P2Luck
        if enemy.type == "LFG":
            enemy.ability("op", "op")
        if enemy.owner == "player1" and enemy.limited > 0:
            enemy.limited -= 1
            if enemy.limited == 0:
                enemy.limited = 20
                return False
            if enemy.type == "HFG":
                P1Luck[0] += 5
                enemy.ability("oo", "oo")
            if random.randint(1, 100) <= P1Luck[0]:
                # goodluck
                P1Luck[0] += 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor += 4
                elif r == 2:
                    enemy.atk(enemy.owner)
                elif r == 3:
                    enemy.attack = int(enemy.attack*2)
                elif r == 4:
                    enemy.moving = True
                elif r == 5:
                    for i in Board:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            if i.card == False:
                                luckyBlock("neutral", "green", i.BoardX, i.BoardY)
                                i.card = True
                return True
            else:
                P1Luck[0] -= 1
                r = random.randint(1, 5)
                if r == 1:
                    update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                    update_data(enemy.type,enemy.owner,'受到傷害', enemy.armor)
                    enemy.armor = 0
                elif r == 2:
                    update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                    update_data(enemy.type,enemy.owner,'受到傷害', int(enemy.health/2))
                    enemy.health = int(enemy.health/2)
                elif r == 3:
                    enemy.canATK = False
                elif r == 4:
                    if enemy.health >= 2:
                        update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                        update_data(enemy.type,enemy.owner,'受到傷害', 2)
                        enemy.health -= 2
                elif r == 5:
                    enemy.attack = int(enemy.attack/2)
                return True
                # badluck
        if enemy.owner == "player2" and enemy.limited > 0:
            enemy.limited -= 1
            if enemy.limited == 0:
                enemy.limited = 20
                return False
            if enemy.type == "HFG":
                P2Luck[0] += 5
                enemy.ability("oo", "oo")
            if random.randint(1, 100) <= P2Luck[0]:
                # goodluck
                P2Luck[0] += 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor += 4
                elif r == 2:
                    enemy.atk(enemy.owner)
                elif r == 3:
                    enemy.attack = int(enemy.attack*2)
                elif r == 4:
                    enemy.moving = True
                elif r == 5:
                    for i in Board:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            if i.card == False:
                                luckyBlock("neutral", "green", i.BoardX, i.BoardY)
                                i.card = True
                return True
            else:
                P2Luck[0] -= 1
                r = random.randint(1, 5)
                if r == 1:
                    update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                    update_data(enemy.type,enemy.owner,'受到傷害', enemy.armor)
                    enemy.armor = 0
                elif r == 2:
                    update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                    update_data(enemy.type,enemy.owner,'受到傷害', int(enemy.health/2))
                    enemy.health = int(enemy.health/2)
                elif r == 3:
                    enemy.canATK = False
                elif r == 4:
                    if enemy.health >= 2:
                        update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                        update_data(enemy.type,enemy.owner,'受到傷害', 2)
                        enemy.health -= 2
                elif r == 5:
                    enemy.attack = int(enemy.attack/2)
                return True
        return False

    def atk(self, turn):
        return False
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        return 0


class ADC(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "ADCG", 3, 3, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        if self.Attack(self.ATKtype.split(" "), 1, turn):
            for i in Board:
                if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                    if i.card == False:
                        if random.randint(1, 2) == 2:
                            luckyBlock(
                                "neutral", "green", i.BoardX, i.BoardY)
                            i.card = True
            return True
        return False
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class ASS(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "ASSG", 2, 4, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class AP(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "APG", 3, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        r = random.randint(1, 5)
        if r == 1:
            self.armor += 4
        elif r == 2:
            self.atk(self.owner)
        elif r == 3:
            self.attack = int(self.attack*2)
        elif r == 4:
            self.moving = True
        elif r == 5:
            pass
        r = random.randint(1, 5)
        if r == 1:
            update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
            update_data(enemy.type,enemy.owner,'受到傷害', enemy.armor)
            enemy.armor = 0
        elif r == 2:
            update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
            update_data(enemy.type,enemy.owner,'受到傷害', int(enemy.health/2))
            enemy.health = int(enemy.health/2)
        elif r == 3:
            enemy.canATK = False
        elif r == 4:
            if enemy.health >= 2:
                update_data(enemy.type,enemy.owner,'受到傷害次數', 1)
                update_data(enemy.type,enemy.owner,'受到傷害', 2)
                enemy.health -= 2
            elif r == 5:
                enemy.attack = int(enemy.attack/2)
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class heavyFighter(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "HFG", 8, 1, x, y)
            
    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        if enemy == "oo" and turn == "oo":
            Min = []
            for i in Board:
                if i.card == False:
                    Min.append(i)
            r = random.randint(0, len(Min)-1)
            luckyBlock("neutral", "green", Min[r].BoardX, Min[r].BoardY)
            Min[r].card = True
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 2, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class lightFighter(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "LFG", 6, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        if enemy == "op" and turn == "op":
            if self.owner == "player1":
                P1atk[0] += 1
            if self.owner == "player2":
                P2atk[0] += 1
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0


class SP(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "SPG", 1, 5, x, y)
            if owner == "player1":
                P1Luck[0] += 10
            if owner == "player2":
                P2Luck[0] += 10

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)
            return 0


class APT(cards):  
    def __init__(self, owner, color, x, y):
        if color == "green":
            self.ATKtype = ""
            super().__init__(owner, "APTG", 8, 0, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        if self.Attack(self.ATKtype.split(" "), 1, turn):
            for i in Board:
                if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                    if i.card == False:
                        luckyBlock("neutral", "green", i.BoardX, i.BoardY)
                        i.card = True
            return True
        return False
    
    def sTurn(self, turn):
        return True
    
    def eTurn(self, turn):
        if self.canATK == False:
            self.canATK = True
            return -1
        else:
            update_data(self.type, self.owner, '得分數', 1)    
            return 0
