from variable import P1matrix,P2matrix, big_text_font, small_text_font, text_font, display_width, display_height, gameDisplay, WHOwin, text_font_size, text_font
import matplotlib.pyplot as plt
from calculate import makebarchart, makepiechart
import os
import pygame
import matplotlib.font_manager as font_manager
pygame.init()

# test
P2matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害次數', '得分數'], ['SPO', 5, 5, 10, 36], ['LFG', 7, 8, 8, 9], ['TANKB', 1, 1, 20, 6], ['ADCDKG', 10, 3, 5, 4]]
P1matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害次數', '得分數'], ['SPO', 5, 5, 10, 36], ['LFG', 7, 8, 8, 9], ['TANKB', 1, 1, 20, 6], ['ADCDKG', 10, 3, 5, 4]]

white = (255, 255, 255)
black = (0, 0, 0)
run = True

code_path = os.getcwd()
relative_font_path = os.path.join(code_path,'8bitOperatorPlus-Bold.ttf')
custom_font_prop = font_manager.FontProperties(fname=relative_font_path)

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))

display = []

class Object:
    def __init__(self, type, x, y, width, height, visule):
        self.type = type
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.visule = visule
        display.append(self)

class Piechart(Object):
    def __init__(self, player, part, x, y):
        super().__init__('piechart', x, y, display_width/4.5, display_width/4.5, False)
        self.player = player
        self.part = part
        file_path = os.path.join(code_path, f'output/P{player}-{part}piechart.png')
        if os.path.exists(file_path):
            self.img = pygame.transform.scale(pygame.image.load(file_path).convert_alpha(), ( int(display_width/5), int(display_width/5)))
        else:
            return None
    def draw(self, screen):
        if self.visule == True:
            screen.blit(self.img, (self.x, self.y))

buttons = []

class Button(Object):
    def __init__(self, x, y, width, height, text, text_size, text_color, bg_color, action, player):
        super().__init__('button', x, y, width, height, True)
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.player = player
        self.text_size = int(text_size)
        self.text_color = text_color
        self.bg_color = bg_color
        self.action = action
        buttons.append(self)

    def draw(self, screen):
        if self.visule == True:
            pygame.draw.rect(screen, self.bg_color, self.rect)
            text_surface = text_font.render(self.text, True, self.text_color)
            text_rect = text_surface.get_rect(center=self.rect.center)
            screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                if self.action:
                    self.action(self, self.player)
last_time = 0
countdown = 0
def playerDisplay(self, player):
    global last_time, countdown
    for i in range(len(display)):
        if display[i].type == "button" and display[i]!=self:
            if display[i].bg_color == (50, 50, 50):
                return False  
    for i in display:
        if i.type == "piechart":
            if i.player == player:
                if i.visule == False:
                    countdown = 4
                    last_time = pygame.time.get_ticks()
                    self.bg_color = (50, 50, 50)
                    return True
                else:
                    i.visule = False
                    self.bg_color = (0, 0, 0)
    return True

def exit(self, player):
    global run
    run = False
    return True

for i in range(1,5):
    makebarchart(P1matrix, i, "P1-")
    makebarchart(P2matrix, i, "P2-")
    makepiechart(P1matrix, i, "P1-")
    Piechart(1, i, display_width/12*i*2, display_height/3*i*0.5)
    makepiechart(P2matrix, i, "P2-")
    Piechart(2, i , display_width/12*i*2, display_height/3*i*0.5)


#create a button

button1 = Button(display_width/2, display_height/10, 100, 50, "P1", text_font_size*1.5, white, black, playerDisplay, 1)
button2 = Button(display_width/2, display_height/10*2, 100, 50, "P2", text_font_size*1.5, white, black, playerDisplay, 2)
button3 = Button(display_width/2, display_height/10*3, 100, 50, "esc", text_font_size*1.5, white, black, exit, None)

mouse_clicked = False

time_delay = 300
clock = pygame.time.Clock()
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not mouse_clicked:
                mouse_clicked = True
                for i in buttons:
                    i.handle_event(event)
    if pygame.mouse.get_pressed()[0] == 0:
        mouse_clicked = False
    
    #time
    current_time = pygame.time.get_ticks()
    
    if current_time - last_time >= time_delay and countdown > 0:
        print(countdown)
        player = 0
        for i in range(len(buttons)):
            if buttons[i].bg_color == (50, 50, 50):
                if buttons[i].player == 1:
                    player = 1
                    break
                if buttons[i].player == 2:
                    player = 2
                    break
        if player != 0:
            for i in range(len(display)):
                if display[i].type == "piechart":
                    if display[i].player == player:
                        if display[i].visule == False:
                            countdown -= 1
                            display[i].visule = True
                            last_time = pygame.time.get_ticks()
                            break


    gameDisplay.fill(black)
    # drawText("P1", small_text_font, white, 10, 10, gameDisplay)
    # drawText("P2", small_text_font, white, 10, 30, gameDisplay)
    for i in display:
        i.draw(gameDisplay)
    pygame.display.update()
    clock.tick(60)
pygame.quit()
