import pygame
pygame.init()
Board = []
player1 = []
player2 = []
neutral = []
displayCardW = []
displayCardR = []
displayCardG = []
displayCardB = []
displayCardO = []
displayCardP = []
displayCardDKG = []
player1Deck = []
player2Deck = []
player1Trash = []
player2Trash = []
player1Hand = []
player2Hand = []
P1Token = [0]
P2Token = [0]
P1totemHP = [0]
P2totemHP = [0]
P1totemAD = [0]
P2totemAD = [0]
p1atk = [1]
p2atk = [0]
P1Cube = [0]
P2Cube = [0]
P1Move = [0]
P2Move = [0]
P1Heal = [0]
P2Heal = [0]
P1Luck = [50]
P2Luck = [50]
P1DrawCard = [0]
P2DrawCard = [0]
Timer = [True]


display_info= pygame.display.get_desktop_sizes()
display_width = display_info[0][0]/2560*2600
display_height = (display_width*15)/26
print(display_width, display_height)
blocksize = display_height/6
gameDisplay = pygame.display.set_mode(
    (display_width, display_height), pygame.FULLSCREEN)

text_font_size = int(display_width/1500*15)
text_font = pygame.font.Font("8bitOperatorPlus-Bold.ttf", text_font_size)
big_text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/1500*25))
small_text_font = pygame.font.Font("8bitOperatorPlus-Bold.ttf", int(text_font_size/15*8.66))

WHOwin = [0]
P1matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害次數', '得分數']]
P2matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害次數', '得分數']]

# 搜索角色是否存在
def search_character(character,owner):
    if owner =="player1":
        for row in range(1, len(P1matrix)):
            if P1matrix[row][0] == character:
                return row
        return -1
    if owner =="player2":
        for row in range(1, len(P2matrix)):
            if P2matrix[row][0] == character:
                return row
        return -1
    return False

def update_data(self,owner,type,data):
    row = search_character(self,owner)
    if owner =="player1":
        if row == -1:
            P1matrix.append([self] +[0] * (len(P1matrix[0]) - 1))
            row = search_character(self,owner)
            return True
        if type =='攻擊次數':
            P1matrix[row][1] += data
            return True
        if type =='造成傷害':
            P1matrix[row][2] += data
            return True
        if type =='受到傷害次數':
            P1matrix[row][3] += data
            return True
        if type =='得分數':
            P1matrix[row][4] += data
            return True
    if owner =="player2":
        if row == -1:
            P2matrix.append([self] +[0] * (len(P2matrix[0]) - 1))
            row = search_character(self,owner)
            return True
        if type =='攻擊次數':
            P2matrix[row][1] += data
            return True
        if type =='造成傷害':
            P2matrix[row][2] += data
            return True
        if type =='受到傷害次數':
            P2matrix[row][3] += data
            return True
        if type =='得分數':
            P2matrix[row][4] += data
            return True
    return False
