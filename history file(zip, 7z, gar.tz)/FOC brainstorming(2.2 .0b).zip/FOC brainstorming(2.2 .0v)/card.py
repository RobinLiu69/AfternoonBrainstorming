from mimetypes import types_map
from variable import *
from calculate import update_data
import random


colors_dict = {'B': "Blue", 'R': "Red", 'G': "Green", 'W': "White", 'O': "Orange", 'P': "Purple", 'DKG': "DarkGreen"}
ATKtype_tags = {'ADC': ("Bigx", "ADC"),
                'AP': ("nearest", "AP"),
                'TANK': ("cross", "TANK"),
                'HF': ("cross x", "HF"),
                'LF': ("cross", "LF"),
                'ASS': ("x", "ASS"),
                'APT': ("nearest", "APT"),
                'SP': ("farest", "SP")}
sorted_tags = sorted(colors_dict.keys(), key=len, reverse=True)

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


class cards:
    def __init__(self, owner, type, health, attack, x, y):
        self.owner = owner
        self.originalAttack = attack
        self.attack = attack
        self.health = health
        self.maxHeart = health
        self.canATK = True
        self.x = x
        self.y = y
        self.Board = x+(y*4)
        self.BoardX = x
        self.BoardY = y
        self.moving = False
        self.armor = 0
        self.type = type
        self.shape = None
        
        name = self.type
        self.ATKtype = None
        types = (0, 0)
        for tag in sorted_tags:
                if name.endswith(tag):
                    name = name.replace(tag, "", 1)
                    break
        for tag in ATKtype_tags.keys():
            if name == tag:
                types = ATKtype_tags[tag]
        self.ATKtype = types[0] # type: ignore
        self.shapeType = types[1] # type: ignore
        if self.type == "cube":
            self.shape = "CUBE"
        elif self.shapeType == "ADC":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)), 
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)))
        elif self.shapeType == "HF":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)))
        elif self.shapeType == "LF":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.36), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.42)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4775), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.55)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.36), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.68)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.64), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.68)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5225), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.55)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.64), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.42)))
        elif self.shapeType == "ASS":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.2), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.8), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)))
        elif self.shapeType == "APT":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)), 
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)))
        elif self.shapeType == "SP":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.375), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.45)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.75)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.45)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.625), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)))
        
        if "ASS" in self.type:
            self.canATK = True
        else:
            self.canATK = False
        if owner == "player1":
            name = self.type
            color = 0
            for tag in sorted_tags:
                if name.endswith(tag):
                    color = colors_dict[tag]
                    break
            if color == 'Blue':
                self.color = (60, 100, 225)
            if color == 'DarkGreen':
                self.color = (85, 107, 47)
            if color == 'Green':
                self.color = (51, 255, 51)
            if color == 'Orange':
                self.color = (255, 69, 0)
            if color == "Purple":
                self.color = (128, 0, 255)
            if color == 'Red':
                self.color = (255, 0, 0)
            if color == 'White':
                self.color = (255, 255, 255)
            player1.append(self)
        elif owner == "player2":
            name = self.type
            color = 0
            for tag in sorted_tags:
                if name.endswith(tag):
                    color = colors_dict[tag]
                    break
            if color == 'Blue':
                self.color = (60, 100, 225)
            if color == 'DarkGreen':
                self.color = (85, 107, 47)
            if color == 'Green':
                self.color = (51, 255, 51)
            if color == 'Orange':
                self.color = (255, 69, 0)
            if color == "Purple":
                self.color = (128, 0, 255)
            if color == 'Red':
                self.color = (255, 0, 0)
            if color == 'White':
                self.color = (255, 255, 255)
            player2.append(self)
        elif owner == "neutral":
            neutral.append(self)
        elif owner == "display":
            name = self.type
            color = 0
            for tag in sorted_tags:
                if name.endswith(tag):
                    color = colors_dict[tag]
                    break
            if color == 'Blue':
                self.canATK = True
                self.color = (60, 100, 225)
                displayCardB.append(self)
            if color == 'DarkGreen':
                self.canATK = True
                self.color = (85, 107, 47)
                displayCardDKG.append(self)
            if color == 'Green':
                self.canATK = True
                self.color = (51, 255, 51)
                displayCardG.append(self)
            if color == 'Orange':
                self.canATK = True
                self.color = (255, 69, 0)
                displayCardO.append(self)
            if color == "Purple":
                self.canATK = True
                self.color = (128, 0, 255)
                displayCardP.append(self)
            if color == 'Red':
                self.canATK=True
                self.color = (255, 0, 0)
                displayCardR.append(self)
            if color == 'White':
                self.canATK = True
                self.color = (255, 255, 255)
                displayCardW.append(self)

    def SPAdd(self,type,value):#Red
        if type=="atk":
            if self.owner=="player1":
                for i in player1:
                    if i.type=="SPR":
                        i.attack+=value
                    
                return True
            if self.owner=="player2":
                for i in player2:
                    if i.type=="SPR":
                        i.attack+=value
        if type=="armor":
            if self.owner=="player1":
                for i in player1:
                    if i.type=="SPR":
                        i.armor+=value
                    
                return True
            if self.owner=="player2":
                for i in player2:
                    if i.type=="SPR":
                        i.armor+=value
                        
                return True
        if type=="hael":
            if self.owner=="player1":
                for i in player1:
                    if i.type=="SPR":
                        i.heal(value)
                    
                return True
            if self.owner=="player2":
                for i in player2:
                    if i.type=="SPR":
                        i.heal(value)

    def toteming(self, number):#DKG
        for i in range(number):
            if random.randint(1, 2) == 1:
                if self.owner == "player1":
                    P1totemHP[0] +=1
                if self.owner == "player2":
                    P2totemHP[0] +=1
            else:
                if self.owner == "player1":
                    P1totemAD[0] +=1
                if self.owner == "player2":
                    P2totemAD[0] +=1
    def move(self, x, y):
        ed = 0
        if Board[x+(y*4)].card == False:
            if ((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y) == 0 and abs(self.x-x) == 1)) and (self.y != y or self.x != x) and self.moving == True:
                ed = 0
            else:
                ed = 1
            if ed == 1:
                self.moving = False
                return False
            if ed == 0:
                Board[self.x+(self.y*4)].card = False
                self.x = x
                self.BoardX = x
                self.y = y
                self.BoardY = y
                self.Board = x+(y*4)
                Board[self.x+(self.y*4)].card = True
                self.moving = False

                #orange
                if self.type == "ADCO":
                    self.Maction(self.owner) # type: ignore
                elif self.type == "HFO":
                    self.Maction(self.owner) # type: ignore
                elif self.type == "LFO":
                    self.Maction(self.owner) # type: ignore
                elif self.type == "ASSO":
                    self.Maction(self.owner) # type: ignore

                if self.owner=="player2":
                    for i in player1:
                        if i.type=="TANKP":
                            self.damage(2, i, self.owner, i.type)  
                if self.owner=="player1":
                    for i in player2:
                        if i.type=="TANKP":
                            self.damage(2, i, self.owner, i.type)   
                if self.owner == "player1":
                    for i in player1:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                if self.owner == "player2":
                    for i in player2:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                return True
        self.moving = False
        return False

    def APTAdd(self, type, value):#blue
        if type == "armor":
            if self.owner == "player1":
                for i in player1:
                    if i.type == "APTB":
                        i.armor += value

                return True
            if self.owner == "player2":
                for i in player2:
                    if i.type == "APTB":
                        i.armor += value
                return True
        return False

    def beenAttack(self, attacker):
        print(f"{self.owner}的{self.type}被{attacker.owner}的{attacker.type}攻擊了")
        update_data(self.type, self.owner, '受到傷害次數', 1)

        #red
        if self.type=="HFR":
            if self.health<=4 and self.anger==False:
                self.attack+=3
                self.SPAdd("atk",3)
                self.anger=True
        if attacker.type=="APR":
            if self.attack>=1:
                attacker.attack+=1
                attacker.SPAdd("atk",1)
                self.attack-=1
        if self.type=="TANKR":      
            if self.owner=="player1":
                Min=[]
                if len(player1)>1:
                    for i in player1:
                        if i != self:
                            Min=[i]
                            break
                elif len(player1)==1:
                    return True
                for i in player1:
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)<abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min=[i]
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)==abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min.append(i)
                if len(Min)>1:
                    i=random.randint(0,len(Min)-1)
                    Min[i].armor+=2
                    self.SPAdd("armor",2)
                    return True
                elif len(Min)==1:
                    Min[0].armor+=2
                    self.SPAdd("armor",2)
                    return True
            elif self.owner=="player2":
                Min=[]
                if len(player2)>1:
                    for i in player2:
                        if i != self:
                            Min=[i]
                            break
                elif len(player2)==1:
                    return True
                for i in player2:
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)<abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min=[i]
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)==abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min.append(i)
                if len(Min)>1:
                    i=random.randint(0,len(Min)-1)
                    Min[i].armor+=2
                    self.SPAdd("armor",2)
                    return True
                elif len(Min)==1:
                    Min[0].armor+=2
                    self.SPAdd("armor",2)
                    return True

        if attacker.type == "APR":
            if self.attack >= 1:
                attacker.attack += 1
                attacker.SPAdd("attack", 1)
                self.attack -= 1

        #blue
        if self.type == "TANKB":
            if self.owner == "player1":
                P1Token[0] += 1
                self.APTAdd("armor", 1)
            if self.owner == "player2":
                P2Token[0] += 1
                self.APTAdd("armor", 1)
        #dkg
        if self.type == "TANKDKG":
                self.toteming(2)
        #green
        if self.type == "luckyBlock":
            self.ability(attacker, self.owner) # type: ignore

        if self.type == "TANKG":
            if self.owner == "player1":
                if random.randint(1, 100) <= P2Luck[0]:
                    pass
                else:
                    r = random.randint(1, 5)
                    if r == 1:
                        update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                        update_data(attacker.type,attacker.owner,'受到傷害', attacker.armor)
                        attacker.armor = 0
                    elif r == 2:
                        update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                        update_data(attacker.type,attacker.owner,'受到傷害', attacker.health - int(attacker.health/2))
                        attacker.health = int(attacker.health/2)
                    elif r == 3:
                        attacker.canATK = False
                    elif r == 4:
                        if attacker.health >= 2:
                            update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                            update_data(attacker.type,attacker.owner,'受到傷害', 2)
                            attacker.health -= 2
                    elif r == 5:
                        attacker.attack = int(attacker.attack/2)
                    # badluck
            if self.owner == "player2":
                if random.randint(1, 100) <= P1Luck[0]:
                    # goodluck
                    pass
                else:
                    r = random.randint(1, 5)
                    if r == 1:
                        update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                        update_data(attacker.type,attacker.owner,'受到傷害', attacker.armor)
                        attacker.armor = 0
                    elif r == 2:
                        update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                        update_data(attacker.type,attacker.owner,'受到傷害', attacker.health - int(attacker.health/2))
                        attacker.health = int(attacker.health/2)
                    elif r == 3:
                        attacker.canATK = False
                    elif r == 4:
                        if attacker.health >= 2:
                            update_data(attacker.type,attacker.owner,'受到傷害次數', 1)
                            update_data(attacker.type,attacker.owner,'受到傷害', 2)
                            attacker.health -= 2
                    elif r == 5:
                        attacker.attack = int(attacker.attack/2)

        #orange
        if self.type == "TANKO":
            if self.owner == "player1":
                player1Hand.append("MOVEO")
            if self.owner == "player2":
                player2Hand.append("MOVEO")  
        return True

    def Kill(self):
        #blue
        if self.type == "ASSB":
            if self.owner == "player1":
                P1Token[0] += 2
                self.APTAdd("armor", 2)
                return True
            elif self.owner == "player2":
                P2Token[0] += 2
                self.APTAdd("armor", 2)
                return True
            
        #dkg
        if self.type == "ASSDKG":
            update_data(self.type,self.owner,'受到傷害次數', 1)
            update_data(self.type,self.owner,'受到傷害', self.health)
            self.D = 1
            return True
        
        #green
        if self.type == "ASSG":
            if self.owner == "player1":
                P1Luck[0] += 5
                P2Luck[0] -= 5
                return True
            if self.owner == "player2":
                P2Luck[0] += 5
                P1Luck[0] -= 5
                return True        
        
        #orange
        if self.type == "ASSO":
            if self.M == 1:
                if self.owner == "player1":
                    p1atk[0] += 1
                    self.M = 0
                if self.owner == "player2":
                    p2atk[0] += 1
                    self.M = 0

        #purple
        if self.type == "ASSP":
            if self.owner == "player1":
                count = int((len(player2) + len(player2Trash))/2)-len(player1)
                if count >= 1:
                    for i in range(0, count):
                        P1DrawCard[0] += 1
            if self.owner == "player2":
                count = int((len(player1) + len(player1Trash))/2)-len(player2)
                if count >= 1:
                    for i in range(0, count):
                        P2DrawCard[0] += 1
        
        #red
        if self.type=="ASSR":
            if self.owner=="player1":
                Min=[]
                if len(player1)>1:
                    for i in player1:
                        if i != self:
                            Min=[i]
                            break
                elif len(player1)==1:
                    return True
                for i in player1:
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)<abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min=[i]
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)==abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min.append(i)
                if len(Min)>1:
                    i=random.randint(0,len(Min)-1)
                    Min[i].armor+=1
                    Min[i].attack+=1
                    self.SPAdd("atk",1)
                    self.SPAdd("armor",1)
                    return True
                elif len(Min)==1:
                    Min[0].armor+=1
                    Min[0].attack+=1
                    self.SPAdd("atk",1)
                    self.SPAdd("armor",1)
                    return True
            elif self.owner=="player2":
                Min=[]
                if len(player2)>1:
                    for i in player2:
                        if i != self:
                            Min=[i]
                            break
                elif len(player1)==1:
                    return True
                for i in player2:
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)<abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min=[i]
                    if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY)==abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i!=self:
                        Min.append(i)
                if len(Min)>1:
                    i=random.randint(0,len(Min)-1)
                    Min[i].armor+=1
                    Min[i].attack+=1
                    self.SPAdd("atk",1)
                    self.SPAdd("armor",1)
                    return True
                elif len(Min)==1:
                    Min[0].armor+=1
                    Min[0].attack+=1
                    self.SPAdd("atk",1)
                    self.SPAdd("armor",1)
                    return True
        return False

    def damage(self, value, dieTo, turn, atkertype):
        if atkertype == "APDKG":
            if dieTo.owner == "player1":
                value += int(P1totemAD[0]/2)
            elif dieTo.owner == "player2":
                value += int(P2totemAD[0]/2)
        if value == 0:
            return True
        if self.armor > 0 and self.armor >= value:
            if self.type != "HFDKG" and self.owner != turn and self.type != atkertype:
                update_data(atkertype, dieTo.owner,'造成傷害',value)
            update_data(self.type, self.owner,'受到傷害',value)
            self.armor -= value
            self.beenAttack(dieTo)
            return True
        elif self.armor > 0 and self.armor < value:
            if self.type != "HFDKG" and self.owner != turn and self.type != atkertype:
                update_data(atkertype, dieTo.owner,'造成傷害',value)
            update_data(self.type, self.owner,'受到傷害',value)
            value = self.armor-value
            self.armor = 0
            self.health += value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        elif self.armor == 0:
            if self.health >= value:
                if self.type != "HFDKG" and self.owner != turn and self.type != atkertype:
                    update_data(atkertype,dieTo.owner,'造成傷害',value)
                update_data(self.type, self.owner,'受到傷害',value)
            if self.health < value:
                if self.type != "HFDKG" and self.owner != turn and self.type != atkertype:
                    update_data(atkertype, dieTo.owner, '造成傷害', self.health)
                update_data(self.type, self.owner, '受到傷害', value)
            self.health -= value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        return False

    def heal(self, value):
        if self.health+value <= self.maxHeart:
            self.health += value
            return True
        elif self.health+value > self.maxHeart and self.health < self.maxHeart:
            self.health = self.maxHeart
            return True
        return False

    def update(self, screen):
        if self.type == "SPG":
            drawText("HP:"+"?", text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.03), screen)
            drawText("ATK:"+"?", text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.03), screen)
            if self.owner != "display":
                drawText(str(self.owner), text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8), screen)
            else:
                drawText(str(self.type), text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8), screen)
            if self.canATK == False:
                drawText("numbness", small_text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.85), screen)
            if self.armor > 0:
                drawText("arm:"+"?", small_text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.12), screen)
            if self.moving == True:
                drawText("Moving", small_text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.12), screen)
        else:
            drawText("HP:"+str(self.health), text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.03), screen)
            drawText("ATK:"+str(self.attack), text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.03), screen)
            if self.owner != "display":
                drawText(str(self.owner), text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8), screen)
            else:
                drawText(str(self.type), text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8), screen)
            if self.canATK == False:
                drawText("numbness", small_text_font, self.color,
                        ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                        (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.85), screen)
            if self.armor > 0:
                drawText("arm:"+str(self.armor), small_text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.1),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.12), screen)
            if self.moving == True:
                drawText("Moving", small_text_font, self.color,
                    ((display_width/2)-(blocksize*2))+(self.x*blocksize)+(blocksize*0.6),
                    (display_height/2)-(blocksize*1.65)+(self.y*blocksize)+(blocksize*0.12), screen)
            
        if self.attack < 0:
            self.attack = 0
        # shapes draw
        
        elif self.shapeType == "ADC":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)), 
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)))
        elif self.shapeType == "HF":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)))
        elif self.shapeType == "LF":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.36), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.42)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4775), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.55)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.36), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.68)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.8)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.64), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.68)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5225), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.55)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.64), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.42)))
        elif self.shapeType == "ASS":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.4)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.2), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.8), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.65)))
        elif self.shapeType == "APT":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.4), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)), 
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.7)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.6), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)))
        elif self.shapeType == "SP":
            self.shape = (((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.375), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.25), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.45)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.75)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.75), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.45)),
                        ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.625), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3)))
        
        if self.shapeType == "TANK":
            pygame.draw.rect(screen, self.color,
                             ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.3), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.3), blocksize*0.4, blocksize*0.4), 4) # type: ignore
        elif self.shapeType == "AP":
            pygame.draw.circle(screen, self.color,
                            ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.5), (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.5)),
                            blocksize*0.2, 3)
        elif self.shape == "CUBE":
            pass
        else:
            pygame.draw.lines(screen, self.color, True, self.shape, 4) # type: ignore

    def Attack(self, type, time, turn):
        if self.canATK == True:
            ed = 0
            if "cross" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "x" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "Bigx" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self, turn, self.type)
                            self.ability(i, turn) # type: ignore
                            ed = 1
                if len(type) == 1 and ed == 1:
                    return True
            if "nearest" in type:
                Min = []
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self, turn, self.type)
                        self.ability(Min[0], turn) # type: ignore
                        return True
            if "farest" in type:
                Min = [] # min暫代最遠的意思
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self, turn, self.type)
                        self.ability(Min[i], turn) # type: ignore
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self, turn, self.type)
                        self.ability(Min[0], turn) # type: ignore
                        return True
            if ed == 1:
                return True
        else:
            return False
