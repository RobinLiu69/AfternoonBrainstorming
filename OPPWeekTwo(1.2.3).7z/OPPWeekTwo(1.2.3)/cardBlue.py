from variable import Board, player1, player2, neutral, displayCardB, display_height, display_width, blocksize, player1Trash, player2Hand, player1Hand, player2Trash, P1Cube, P2Cube, P1Heal, P2Heal, P1Move, P2Move, P1Token, P2Token, player1Trash, player2Trash, big_text_font, small_text_font, text_font
import random
import pygame
pygame.init()

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


class cards:
    def __init__(self, owner, type, health, attack, x, y):
        self.owner = owner
        self.originalAttack = attack
        self.attack = attack
        self.health = health
        self.maxHeart = health
        self.canATK = True
        self.x = x
        self.y = y
        self.Board = x+(y*4)
        self.BoardX = x
        self.BoardY = y
        self.moving = False
        self.armor = 0
        self.type = type
        if self.type == "ASSB":
            self.canATK = True
        else:
            self.canATK = False
        if owner == "player1":
            player1.append(self)
        elif owner == "player2":
            player2.append(self)
        elif owner == "neutral":
            neutral.append(self)
        elif owner == "display":
            self.canATK = True
            displayCardB.append(self)

    def move(self, x, y):
        ed = 0
        if Board[x+(y*4)].card == False:
            if ((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y) == 0 and abs(self.x-x) == 1)) and (self.y != y or self.x != x) and self.moving == True:
                ed = 0
            else:
                ed = 1
            if ed == 1:
                self.moving = False
                return False
            if ed == 0:
                Board[self.x+(self.y*4)].card = False
                self.x = x
                self.BoardX = x
                self.y = y
                self.BoardY = y
                self.Board = x+(y*4)
                Board[self.x+(self.y*4)].card = True
                self.moving = False
                if self.owner=="player2":
                    for i in player1:
                        if i.type=="TANKP":
                            self.damage(2,i)
                if self.owner=="player1":
                    for i in player2:
                        if i.type=="TANKP":
                            self.damage(2,i)  
                if self.owner == "player1":
                    for i in player1:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                if self.owner == "player2":
                    for i in player2:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                return True
        self.moving = False
        return False

    def APTAdd(self, type, value):
        if type == "armor":
            if self.owner == "player1":
                for i in player1:
                    if i.type == "APTB":
                        i.armor += value

                return True
            if self.owner == "player2":
                for i in player2:
                    if i.type == "APTB":
                        i.armor += value

                return True

    def beenAttack(self, attacker):
        if attacker.type == "APR":
            if self.attack >= 1:
                attacker.attack += 1
                attacker.SPAdd("attack", 1)
                self.attack -= 1
        if self.type == "TANKB":
            if self.owner == "player1":
                P1Token[0] += 1
                self.APTAdd("armor", 1)
            if self.owner == "player2":
                P2Token[0] += 1
                self.APTAdd("armor", 1)

    def Kill(self):
        if self.type == "ASSB":
            if self.owner == "player1":
                P1Token[0] += 2
                self.APTAdd("armor", 2)
                return True
            elif self.owner == "player2":
                P2Token[0] += 2
                self.APTAdd("armor", 2)
                return True
        return False

    def damage(self, value, dieTo):
        if value == 0:
            return True
        if self.armor > 0 and self.armor >= value:
            self.armor -= value
            self.beenAttack(dieTo)
            return True
        elif self.armor > 0 and self.armor < value:
            value = self.armor-value
            self.armor = 0
            self.health += value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        elif self.armor == 0:
            self.health -= value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        return False

    def heal(self, value):
        if self.health+value <= self.maxHeart:
            self.health += value
            return True
        elif self.health+value > self.maxHeart and self.health < self.maxHeart:
            self.health = self.maxHeart
            return True
        return False

    def update(self, screen):
        drawText("HP:"+str(self.health), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        drawText("ATK:"+str(self.attack), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        if self.owner != "display":
            drawText(str(self.owner), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        else:
            drawText(str(self.type), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        if self.canATK == False:
            drawText("numbness", small_text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/18), (display_height/3.529)+(self.y*blocksize)+(display_height/10.714), screen)
        if self.armor >= 1:
            drawText("arm:"+str(self.armor), small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
        if self.moving == True:
            drawText("Moving", small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
            
        if self.attack<0:
            self.attack=0

    def Attack(self, type, time, turn):
        if self.canATK == True:
            ed = 0
            if "cross" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "x" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "Bigx" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if time > 1 and ed == 1:
                    return True
            if "nearest" in type:
                Min = []
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if "farest" in type:
                Min = []
                # min暫代最遠
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if time > 1 and ed == 1:
                return True
        else:
            return False


def playCardBlue(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2857) and Board[BX+(BY*4)].card == False:
            if card == "SPB":
                new = SP("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTB":
                new = APT("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APB":
                new = AP("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCB":
                new = ADC("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKB":
                new = TANK("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFB":
                new = heavyFighter("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFB":
                new = lightFighter("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSB":
                new = ASS("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True

    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2857) and Board[BX+(BY*4)].card == False:
            if card == "SPB":
                new = SP("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTB":
                new = APT("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APB":
                new = AP("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCB":
                new = ADC("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKB":
                new = TANK("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFB":
                new = heavyFighter("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFB":
                new = lightFighter("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSB":
                new = ASS("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "TANKB", 10, 1, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "ADCB", 4, 2, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["Bigx"], 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "ASSB", 2, 4, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["x"], 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "APB", 4, 2, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize) +
                           50+(display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        if self.type == "APB":
            if self.owner == "player1":
                P1Token[0] += 2
                self.APTAdd("armor", 2)
                return True
            elif self.owner == "player2":
                P2Token[0] += 2
                self.APTAdd("armor", 2)
                return True
        return True

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "HFB", 8, 1, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        if self.owner == "player1":
            self.attack += P1Token[0]
        if self.owner == "player2":
            self.attack += P2Token[0]
        TF = self.Attack(["cross", "x"], 2, turn)
        if self.owner == "player1":
            self.attack -= P1Token[0]
        if self.owner == "player2":
            self.attack -= P2Token[0]
        return TF



class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "LFB", 6, 3, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if self.owner == "player1":
            P1Token[0] += 1
            self.APTAdd("armor", 1)
            return True
        elif self.owner == "player2":
            P2Token[0] += 1
            self.APTAdd("armor", 1)
            return True
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "SPB", 1, 5, x, y)
            color = (60, 100, 225)
            self.color = color
        if self.owner == "player1":
            if len(player1Trash)+len(player1) >= 2:
                for i in range(0, len(player1Trash)+len(player1)-2):
                    if len(player2) >= 1 or len(neutral) >= 1:
                        Min = []
                        for i in player2:
                            Min.append(i)
                        for i in neutral:
                            Min.append(i)
                        Min[random.randint(0, len(Min)-1)].damage(1, self)
        if self.owner == "player2":
            if len(player2Trash)+len(player2) >= 2:
                for i in range(0, len(player2Trash)+len(player2)-2):
                    if len(player1) >= 1 or len(neutral) >= 1:
                        Min = []
                        for i in player1:
                            Min.append(i)
                        for i in neutral:
                            Min.append(i)
                        Min[random.randint(0, len(Min)-1)].damage(1, self)

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(
            self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["farest"], 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "APTB", 4, 2, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)
