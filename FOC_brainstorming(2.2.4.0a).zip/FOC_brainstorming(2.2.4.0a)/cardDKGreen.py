from variable import *
from calculate import update_data
from card import cards

def playCardDKGreen(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/2-blocksize*2) and mouseY > (display_height/2-blocksize*1.65) and Board[BX+(BY*4)].card == False:
            if card == "SPDKG":
                SP("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTDKG":
                APT("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APDKG":
                AP("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCDKG":
                ADC("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKDKG":
                TANK("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFDKG":
                heavyFighter("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFDKG":
                lightFighter("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSDKG":
                ASS("player1", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPDKG":
                SP("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTDKG":
                APT("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APDKG":
                AP("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCDKG":
                ADC("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKDKG":
                TANK("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFDKG":
                heavyFighter("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFDKG":
                lightFighter("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSDKG":
                ASS("player2", "dkgreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
    return False



class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "TANKDKG", 9, 1, x, y)


    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
    
class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "ADCDKG", 4, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        self.toteming(1)
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "ASSDKG", 2, 4, x, y)
            self.D = 0

    def display(self, screen):
        if self.D==1:
            self.toteming(6)
            self.health=0
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "APDKG", 4, 0, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
        

class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "HFDKG", 8, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        self.heal(1)
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "LFDKG", 6, 3, x, y)
            if owner=="player1":
                for i in player2:
                    self.toteming(1)
            if owner=="player2":
                for i in player1:
                    self.toteming(1)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "SPDKG", 1, 3, x, y)
            if owner=="player1":
                if P1totemHP[0]>=2:
                    self.armor+=int(P1totemHP[0]-1)
                    P1totemHP[0]=0
                if P1totemAD[0]>=2:
                    self.attack+=int(P1totemAD[0])
                    P1totemAD[0]=0
            if owner=="player2":
                if P2totemHP[0]>=2:
                    self.armor+=int(P2totemHP[0]-1)
                    P2totemHP[0]=0
                if P2totemAD[0]>=2:
                    self.attack+=int(P2totemAD[0])
                    P2totemAD[0]=0

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "dkgreen":
            self.ATKtype = ""
            super().__init__(owner, "APTDKG", 2, 2, x, y)
            if owner=="player1":
                self.armor+=int(P1totemHP[0]/2)
            if owner=="player2":
                self.armor+=int(P2totemHP[0]/2)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
