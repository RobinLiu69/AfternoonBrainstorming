from variable import *
from calculate import update_data
from card import cards
import random
import pygame

def playCardWhite(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/2-blocksize*2) and mouseY > (display_height/2-blocksize*1.65) and Board[BX+(BY*4)].card == False:
            if card == "SPW":
                SP("player1", "white", BX, BY)

                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTW":
                APT("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APW":
                AP("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCW":
                ADC("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKW":
                TANK("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFW":
                heavyFighter("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFW":
                lightFighter("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSW":
                ASS("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True

        if card == "CUBE":
            P1Cube[0] += 2
            tag = 1
        if card == "HEAL":
            P1Heal[0] += 1
            tag = 1
        if card == "MOVE":
            P1Move[0] += 1
            tag = 1
        if tag == 1:
            player1Trash.append(card)
            player1Hand.remove(card)
            return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPW":
                SP("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTW":
                APT("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APW":
                AP("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCW":
                ADC("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKW":
                TANK("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFW":
                heavyFighter("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFW":
                lightFighter("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSW":
                ASS("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
        if card == "CUBE":
            P2Cube[0] += 2
            tag = 1
        if card == "HEAL":
            P2Heal[0] += 1
            tag = 1
        if card == "MOVE":
            P2Move[0] += 1
            tag = 1
        if tag == 1:
            player2Trash.append(card)
            player2Hand.remove(card)
            return True
    return False



class cube(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "cube", 4, 0, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/2-blocksize*2)+(self.x*blocksize)+(blocksize*0.425),
                          (display_height/2-blocksize*1.65)+(self.y*blocksize)+(blocksize*0.425),
                          blocksize*0.15, blocksize*0.15), 4) # type: ignore
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "TANKW", 15, 1, x, y)
    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "ADCW", 5, 4, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "ASSW", 2, 5, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "APW", 4, 3, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "HFW", 9, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "LFW", 7, 3, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "SPW", 1, 5, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            self.ATKtype = ""
            super().__init__(owner, "APTW", 8, 2, x, y)

    def display(self, screen):
        self.update(screen)

    def ability(self, enemy, turn):
        if turn == "player1":
            Min = []
            if len(player1) > 1:
                for i in player1:
                    if i != self:
                        Min = [i]
                        break
            elif len(player1) == 1:
                self.armor += 2
                return True
            for i in player1:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        elif turn == "player2":
            Min = []
            if len(player2) > 1:
                for i in player2:
                    if i != self:
                        Min = [i]
                        break
            elif len(player2) == 1:
                self.armor += 2
                return True
            for i in player2:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        return False

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
