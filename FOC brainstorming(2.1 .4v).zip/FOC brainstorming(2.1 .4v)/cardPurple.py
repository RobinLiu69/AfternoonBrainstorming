from variable import *
from calculate import update_data
from card import cards
import random
import pygame
pygame.init()

def playCardPurple(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPP":
                SP("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTP":
                APT("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APP":
                AP("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCP":
                ADC("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKP":
                TANK("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFP":
                heavyFighter("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFP":
                lightFighter("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSP":
                ASS("player1", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPP":
                SP("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTP":
                APT("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APP":
                AP("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCP":
                ADC("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKP":
                TANK("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFP":
                heavyFighter("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFP":
                lightFighter("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSP":
                ASS("player2", "purple", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
    return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "TANKP", 9, 1, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "ADCP", 5, 4, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "ASSP", 2, 3, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "APP", 3, 1, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize)+50+(
            display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        enemy.armor = 0
        enemy.attack = enemy.originalAttack
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "HFP", 9, 2, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "LFP", 7, 3, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "SPP", 1, 5, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x *
                                                                                                                                                                                                                                                                                           blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "purple":
            super().__init__(owner, "APTP", 8, 2, x, y)
            color = (128, 0, 255)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        if turn == "player1":
            Min = []
            if len(player1) > 1:
                for i in player1:
                    if i != self:
                        Min = [i]
                        break
            elif len(player1) == 1:
                self.armor += 2
                return True
            for i in player1:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        elif turn == "player2":
            Min = []
            if len(player2) > 1:
                for i in player2:
                    if i != self:
                        Min = [i]
                        break
            elif len(player2) == 1:
                self.armor += 2
                return True
            for i in player2:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        return False

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
