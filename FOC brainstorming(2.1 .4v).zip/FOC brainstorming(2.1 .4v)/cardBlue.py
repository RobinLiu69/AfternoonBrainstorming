from variable import *
from calculate import update_data
from card import cards
import random
import pygame
pygame.init()

def playCardBlue(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2857) and Board[BX+(BY*4)].card == False:
            if card == "SPB":
                SP("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTB":
                APT("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APB":
                AP("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCB":
                ADC("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKB":
                TANK("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFB":
                heavyFighter("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFB":
                lightFighter("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSB":
                ASS("player1", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True

    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2857) and Board[BX+(BY*4)].card == False:
            if card == "SPB":
                SP("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTB":
                APT("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APB":
                AP("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCB":
                ADC("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKB":
                TANK("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFB":
                heavyFighter("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFB":
                lightFighter("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSB":
                ASS("player2", "blue", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "TANKB", 10, 1, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "ADCB", 4, 3, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "ASSB", 2, 4, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "APB", 4, 2, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize) +
                           50+(display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        if self.type == "APB":
            if self.owner == "player1":
                P1Token[0] += 2
                self.APTAdd("armor", 2)
                return True
            elif self.owner == "player2":
                P2Token[0] += 2
                self.APTAdd("armor", 2)
                return True
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "HFB", 8, 1, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        if self.owner == "player1":
            self.attack += P1Token[0]
        if self.owner == "player2":
            self.attack += P2Token[0]
        TF = self.Attack(self.ATKtype.split(" "), 2, turn)
        if self.owner == "player1":
            self.attack -= P1Token[0]
        if self.owner == "player2":
            self.attack -= P2Token[0]
        return TF



class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "LFB", 6, 3, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if self.owner == "player1":
            P1Token[0] += 1
            self.APTAdd("armor", 1)
            return True
        elif self.owner == "player2":
            P2Token[0] += 1
            self.APTAdd("armor", 1)
            return True
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "SPB", 1, 5, x, y)
            color = (60, 100, 225)
            self.color = color
        if self.owner == "player1":
            if len(player1Trash)+len(player1) >= 2:
                for i in range(0, len(player1Trash)+len(player1)):
                    if len(player2) >= 1 or len(neutral) >= 1:
                        Min = []
                        for i in player2:
                            Min.append(i)
                        for i in neutral:
                            Min.append(i)
                        Min[random.randint(0, len(Min)-1)].damage(1, self,self.owner,self.type)
                update_data(self.type, owner,'攻擊次數',1)
        if self.owner == "player2":
            if len(player2Trash)+len(player2) >= 2:
                for i in range(0, len(player2Trash)+len(player2)):
                    if len(player1) >= 1 or len(neutral) >= 1:
                        Min = []
                        for i in player1:
                            Min.append(i)
                        for i in neutral:
                            Min.append(i)
                        Min[random.randint(0, len(Min)-1)].damage(1, self,self.owner,self.type)
                update_data(self.type, owner,'攻擊次數',1)

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(
            self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "blue":
            super().__init__(owner, "APTB", 4, 2, x, y)
            color = (60, 100, 225)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        return self.Attack(self.ATKtype.split(" "), 1, turn)
