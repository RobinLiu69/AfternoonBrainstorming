import concurrent.futures
import time

def waitdisplay():
    # 假設這是一個耗時的操作
    time.sleep(6)
    return "waitdisplay is done"

# 使用 ThreadPoolExecutor 創建線程池
with concurrent.futures.ThreadPoolExecutor() as executor:
    # 提交任務給線程池，並取得 Future 物件
    future = executor.submit(waitdisplay)

    # 立即打印 "future is doing"
    print("future is doing")

    # 使用 as_completed 迭代器等待任務完成
    for completed_future in concurrent.futures.as_completed([future]):
        result = completed_future.result()
        print(result)

print("future is done")
# 主線程繼續執行
print("Main thread is done")
