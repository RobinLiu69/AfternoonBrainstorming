from variable import text_font_size
import matplotlib.pyplot as plt
import os
import matplotlib.font_manager as font_manager


code_path = os.getcwd()
relative_font_path = os.path.join(code_path,'8bitOperatorPlus-Bold.ttf')
custom_font_prop = font_manager.FontProperties(fname=relative_font_path)

def makepiechart(data, parts, whose): 
    # 1='攻擊次數', 2='造成傷害', 3='受到傷害次數', 4='得分數'
    # '攻擊次數': 'Number of Attacks'(NoA)
    # '造成傷害': 'Damage Dealt'(DD)
    # '受到傷害次數': 'Number of Hits Taken'(NoHT)
    # '得分數': 'Score'(Score)
    if len(data)> 0:
        tag=False
        labels = [data[i][0] for i in range(1,len(data))]
        colors_dict = {'B': (60/255, 100/255, 225/255), 'R': (255/255, 0/255, 0/255), 'G': (51/255, 255/255, 51/255), 'W': (255/255, 255/255, 255/255), 'O': (255/255, 69/255, 0/255), 'P': (128/255, 0/255, 255/255), 'DKG': (85/255, 107/255, 47/255)}
        my_list = {
                1: 'NoA',
                2: 'DD',
                3: 'NoHT',
                4: 'Score'
            }
        title_text=my_list[parts]
        sorted_tags = sorted(colors_dict.keys(), key=len, reverse=True)

        colors = []
        for name in labels:
            for tag in sorted_tags:
                if name.endswith(tag):
                    colors.append(colors_dict[tag])
                    break

        sizes =  [data[i][parts] for i in range(1,len(data))]
        for i in range(len(sizes)):
            if sizes[i] > 0:
                tag=True
                break
        if tag==False:
            return False
    else:
        return False
    plt.figure(figsize=(15, 15), dpi=120)
    _, texts, _ = plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140, labeldistance=1.1, textprops={'color': 'black', 'fontproperties': custom_font_prop, 'fontsize': text_font_size*1.5}, wedgeprops={'linewidth': 5, 'edgecolor': 'gray'})
    plt.axis('equal')
    for text in texts:
        text.set_color('white')
        text.set_fontsize(text_font_size*2)
    plt.title(title_text, fontweight='bold', fontproperties=custom_font_prop, fontsize = text_font_size*3, color = 'white', loc='center', pad=30)
    plt.tight_layout()
    output_folder = './output'
    os.makedirs(output_folder, exist_ok=True)
    plt.savefig(os.path.join(output_folder, whose+str(parts)+"piechart"+".png"), transparent=True)
    plt.close()
    return True


def makebarchart(data, parts, whose): 
    # 1='攻擊次數', 2='造成傷害', 3='受到傷害次數', 4='得分數'
    # '攻擊次數': 'Number of Attacks'(NoA)
    # '造成傷害': 'Damage Dealt'(DD)
    # '受到傷害次數': 'Number of Hits Taken'(NoHT)
    # '得分數': 'Score'(Score)
    if len(data)> 0:
        tag=False
        labels = [data[i][0] for i in range(1,len(data))]
        colors_dict = {'B': (60/255, 100/255, 225/255), 'R': (255/255, 0/255, 0/255), 'G': (51/255, 255/255, 51/255), 'W': (255/255, 255/255, 255/255), 'O': (255/255, 69/255, 0/255), 'P': (128/255, 0/255, 255/255), 'DKG': (85/255, 107/255, 47/255)}
        my_list = {
                1: 'DD/NoA',#平均攻擊傷害
                2: 'NoA/NoHT',#攻擊效率指數
                3: 'DD/Score',#傷害效率
                4: 'max(Score-NoHT,0)/NoA'#生存指數
            }
        my_titlelist = {
                1: 'Average Attack Damage',
                2: 'Attack Efficiency Index',
                3: 'Damage Efficiency',
                4: 'Survival Index'
            }
        title_text=my_titlelist[parts]
        sorted_tags = sorted(colors_dict.keys(), key=len, reverse=True)

        colors = []
        for name in labels:
            for tag in sorted_tags:
                if name.endswith(tag):
                    colors.append(colors_dict[tag])
                    break
        if parts == 1:
            # 'DD/NoA',平均攻擊傷害
            sizes =  [data[i][2]/(data[i][1]+1) for i in range(1,len(data))]
        if parts == 2:
            # 'NoA/NoHT',攻擊效率指數
            sizes =  [data[i][1]/(data[i][3]+1) for i in range(1,len(data))]
        if parts == 3:
            # 'DD/Score',傷害效率
            sizes =  [data[i][2]/(data[i][4]+1) for i in range(1,len(data))]
        if parts == 4:
            # 'max(Score-NoHT,0)/NoA',生存指數
            sizes =  [max(data[i][4]-data[i][3],0)/(data[i][1]+1) for i in range(1,len(data))]
        for i in range(len(sizes)):
            if sizes[i] > 0:
                tag=True
                break
        if tag==False:
            return False
    else:
        return False
    
    plt.figure(dpi=120) #導致pygame視窗改變
    plt.barh(labels, sizes, color = colors, linewidth = 5, edgecolor = "gray")
    plt.title(title_text, fontweight = 'bold', fontproperties=custom_font_prop, fontsize = 20, color = 'white', loc='center', pad=30)
    #--------------------------------------------------------------------------------
    for label in plt.gca().get_yticklabels():
        label.set_fontproperties(custom_font_prop)
        label.set_color("white")
        label.set_fontsize(25)
    plt.tick_params(axis = 'x', colors = "white", labelsize=text_font_size*1.25)
    plt.tick_params(axis = 'y', colors = "white", labelsize=text_font_size*1.25)
    #--------------------------------------------------------------------------------問題應該在這部份
    plt.gca().spines['top'].set_visible(False)
    plt.gca().spines['right'].set_visible(False)
    plt.gca().spines['bottom'].set_visible(False)
    plt.gca().spines['left'].set_visible(False)

    plt.tight_layout()

    output_folder = './output'
    os.makedirs(output_folder, exist_ok=True)
    plt.savefig(os.path.join(output_folder, whose+str(parts)+"barchart"+".png"), transparent=True)
    plt.close()
    return True