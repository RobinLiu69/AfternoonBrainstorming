from variable import Board, player1, player2, neutral, displayCardG, display_height, blocksize, display_width, player2Hand, player1Hand, P1Luck, P2Luck, p1atk, p2atk, big_text_font, small_text_font, text_font
import random
import pygame
print("import pygame")
pygame.init()
print("init")

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


class cards:
    def __init__(self, owner, type, health, attack, x, y):
        self.owner = owner
        self.originalAttack = attack
        self.attack = attack
        self.health = health
        self.maxHeart = health
        self.canATK = True
        self.x = x
        self.y = y
        self.Board = x+(y*4)
        self.BoardX = x
        self.BoardY = y
        self.moving = False
        self.armor = 0
        self.type = type
        if self.type == "ASSG":
            self.canATK = True
        else:
            self.canATK = False
        if owner == "player1":
            player1.append(self)
        elif owner == "player2":
            player2.append(self)
        elif owner == "neutral":
            neutral.append(self)
        elif owner == "display":
            self.canATK = True
            displayCardG.append(self)

    def move(self, x, y):
        ed = 0
        if Board[x+(y*4)].card == False:
            print(((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y)
                  == 0 and abs(self.x-x) == 1)), (self.y != y or self.x != x), self.moving == True)
            if ((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y) == 0 and abs(self.x-x) == 1)) and (self.y != y or self.x != x) and self.moving == True:
                ed = 0
            else:
                ed = 1
            if ed == 1:
                self.moving = False
                return False
            if ed == 0:
                Board[self.x+(self.y*4)].card = False
                self.x = x
                self.BoardX = x
                self.y = y
                self.BoardY = y
                self.Board = x+(y*4)
                Board[self.x+(self.y*4)].card = True
                self.moving = False
                if self.owner=="player2":
                    for i in player1:
                        if i.type=="TANKP":
                            self.damage(2,i)
                if self.owner=="player1":
                    for i in player2:
                        if i.type=="TANKP":
                            self.damage(2,i)
                if self.owner == "player1":
                    for i in player1:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                if self.owner == "player2":
                    for i in player2:
                        if i.type == "APTO":
                            i.Maction(i.owner)
                        if i.type == "SPO":
                            i.Maction(i.owner)
                return True
        self.moving = False
        return False

    def beenAttack(self, attacker):
        global P1Luck, P2Luck
        if attacker.type == "APR":
            if self.attack >= 1:
                attacker.attack += 1
                attacker.SPAdd("atk", 1)
                self.attack -= 1
        if self.type == "luckyBlock":
            self.ability(attacker, self.owner)

        if self.type == "TANKG":
            if self.owner == "player1":
                if random.randint(1, 100) <= P2Luck[0]:
                    pass
                else:
                    r = random.randint(1, 5)
                    if r == 1:
                        attacker.armor = 0
                    elif r == 2:
                        attacker.health = int(attacker.health/2)
                    elif r == 3:
                        attacker.canATK = False
                    elif r == 4:
                        if attacker.health >= 2:
                            attacker.health -= 2
                    elif r == 5:
                        attacker.attack = int(attacker.attack/2)
                    # badluck
            if self.owner == "player2":
                if random.randint(1, 100) <= P1Luck[0]:
                    # goodluck
                    pass
                else:
                    r = random.randint(1, 5)
                    if r == 1:
                        attacker.armor = 0
                    elif r == 2:
                        attacker.health = int(attacker.health/2)
                    elif r == 3:
                        attacker.canATK = False
                    elif r == 4:
                        if attacker.health >= 2:
                            attacker.health -= 2
                    elif r == 5:
                        attacker.attack = int(attacker.attack/2)

    def Kill(self):
        global P1Luck, P2Luck
        if self.type == "ASSG":
            if self.owner == "player1":
                P1Luck[0] += 5
                P2Luck[0] -= 5
            if self.owner == "player2":
                P2Luck[0] += 5
                P1Luck[0] -= 5

        return True

    def damage(self, value, dieTo):
        if value == 0:
            return True
        if self.armor > 0 and self.armor >= value:
            self.armor -= value
            self.beenAttack(dieTo)
            return True
        elif self.armor > 0 and self.armor < value:
            value = self.armor-value
            self.armor = 0
            self.health += value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        elif self.armor == 0:
            self.health -= value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        return False

    def heal(self, value):
        if self.health+value <= self.maxHeart:
            self.health += value
            return True
        elif self.health+value > self.maxHeart and self.health < self.maxHeart:
            self.health = self.maxHeart
            return True
        return False

    def update(self, screen):
        drawText("HP:"+str(self.health), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        drawText("ATK:"+str(self.attack), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        if self.owner != "display":
            drawText(str(self.owner), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        else:
            drawText(str(self.type), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        if self.canATK == False:
            drawText("numbness", small_text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/18), (display_height/3.529)+(self.y*blocksize)+(display_height/10.714), screen)
        if self.armor >= 1:
            drawText("arm:"+str(self.armor), small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
        if self.moving == True:
            drawText("Moving", small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
            
        if self.attack<0:
            self.attack=0


    def Attack(self, type, time, turn):
        if self.canATK == True:
            ed = 0
            if "cross" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "x" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "Bigx" in type:
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "nearest" in type:
                Min = []
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        print(neutral)
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if "farest" in type:
                Min = []
                # min暫代最遠
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        print(neutral)
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if time > 1 and ed == 1:
                return True
            return False
        else:
            return False


def playCardGreen(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPG":
                new = SP("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTG":
                new = APT("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APG":
                new = AP("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCG":
                new = ADC("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKG":
                new = TANK("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFG":
                new = heavyFighter("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFG":
                new = lightFighter("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSG":
                new = ASS("player1", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPG":
                new = SP("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTG":
                new = APT("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APG":
                new = AP("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCG":
                new = ADC("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKG":
                new = TANK("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFG":
                new = heavyFighter("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFG":
                new = lightFighter("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSG":
                new = ASS("player2", "green", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
    return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "TANKG", 10, 1, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class luckyBlock(cards):
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "luckyBlock", 1, 0, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25, 50, 50), 4)
        drawText("?", text_font, (51, 255, 51), (display_width/3.2)+(self.x*blocksize) +
                 40+(display_width/40), (display_height/3.529)+(self.y*blocksize)+30, screen)
        self.update(screen)

    def ability(self, enemy, turn):
        global P1Luck, P2Luck
        if enemy.type == "LFG":
            enemy.ability("op", "op")
        if enemy.owner == "player1":
            if enemy.type == "HFG":
                P1Luck += 5
                enemy.ability("oo", "oo")
            if random.randint(1, 100) <= P1Luck[0]:
                # goodluck
                P1Luck[0] += 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor += 4
                elif r == 2:
                    enemy.atk(enemy.owner)
                elif r == 3:
                    enemy.attack = int(enemy.attack*2)
                elif r == 4:
                    enemy.moving = True
                elif r == 5:
                    for i in Board:
                        if i.card == False:
                            if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                                new = luckyBlock(
                                    "neutral", "green", i.BoardX, i.BoardY)
                                i.card = True
                return True
            else:
                P1Luck[0] -= 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor = 0
                elif r == 2:
                    enemy.health = int(enemy.health/2)
                elif r == 3:
                    enemy.canATK = False
                elif r == 4:
                    if enemy.health >= 2:
                        enemy.health -= 2
                elif r == 5:
                    enemy.attack = int(enemy.attack/2)
                # badluck
        if enemy.owner == "player2":
            if enemy.type == "HFG":
                P2Luck[0] += 5
                enemy.ability("oo", "oo")
            if random.randint(1, 100) <= P2Luck[0]:
                # goodluck
                P2Luck[0] += 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor += 4
                elif r == 2:
                    enemy.atk(enemy.owner)
                elif r == 3:
                    enemy.attack = int(enemy.attack*2)
                elif r == 4:
                    enemy.moving = True
                elif r == 5:
                    for i in Board:
                        if i.card == False:
                            if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                                new = luckyBlock(
                                    "neutral", "green", i.BoardX, i.BoardY)
                                i.card = True
                return True
            else:
                P2Luck[0] -= 1
                r = random.randint(1, 5)
                if r == 1:
                    enemy.armor = 0
                elif r == 2:
                    enemy.health = int(enemy.health/2)
                elif r == 3:
                    enemy.canATK = False
                elif r == 4:
                    if enemy.health >= 2:
                        enemy.health -= 2
                elif r == 5:
                    enemy.attack = int(enemy.attack/2)
        return True

    def atk(self, turn):
        return False


class ADC(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "ADCG", 3, 3, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        if self.Attack(["Bigx"], 1, turn):
            for i in Board:
                if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                    if i.card == False:
                        if random.randint(1, 2) == 2:
                            new = luckyBlock(
                                "neutral", "green", i.BoardX, i.BoardY)
                            i.card = True
            return True
        return False


class ASS(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "ASSG", 2, 4, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["x"], 1, turn)


class AP(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "APG", 3, 2, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize)+50+(
            display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        r = random.randint(1, 5)
        if r == 1:
            self.armor += 4
        elif r == 2:
            self.atk(self.owner)
        elif r == 3:
            self.attack = int(self.attack*2)
        elif r == 4:
            self.moving = True
        elif r == 5:
            pass
        r = random.randint(1, 5)
        if r == 1:
            enemy.armor = 0
        elif r == 2:
            enemy.health = int(enemy.health/2)
        elif r == 3:
            enemy.canATK = False
        elif r == 4:
            if enemy.health >= 2:
                enemy.health -= 2
        elif r == 5:
            enemy.attack = int(enemy.attack/2)
        return True

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)


class heavyFighter(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "HFG", 8, 1, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if enemy == "oo" and turn == "oo":
            Min = []
            for i in Board:
                if i.card == False:
                    Min.append(i)
            r = random.randint(0, len(Min)-1)
            new = luckyBlock("neutral", "green", Min[r].BoardX, Min[r].BoardY)
            Min[r].card = True
        return True

    def atk(self, turn):
        return self.Attack(["cross", "x"], 2, turn)


class lightFighter(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "LFG", 6, 2, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if enemy == "op" and turn == "op":
            if self.owner == "player1":
                p1atk[0] += 1
            if self.owner == "player2":
                p2atk[0] += 1
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class SP(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "SPG", 1, 5, x, y)
            color = (51, 255, 51)
            self.color = color
            if owner == "player1":
                P1Luck[0] += 10
            if owner == "player2":
                P2Luck[0] += 10

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x *
                                                                                                                                                                                                                                                                                           blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        drawText("HP:"+"?", text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        drawText("ATK:"+"?", text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        if self.owner != "display":
            drawText(str(self.owner), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        else:
            drawText(str(self.type), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        if self.canATK == False:
            drawText("numbness", small_text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/18), (display_height/3.529)+(self.y*blocksize)+(display_height/10.714), screen)
        if self.armor >= 1:
            drawText("arm:"+"?", small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
        if self.moving == True:
            drawText("Moving", small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["farest"], 1, turn)


class APT(cards):  # tt
    def __init__(self, owner, color, x, y):
        if color == "green":
            super().__init__(owner, "APTG", 8, 0, x, y)
            color = (51, 255, 51)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        if self.Attack(["nearest"], 1, turn):
            for i in Board:
                if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                    # print("attck")
                    if i.card == False:
                        print(i.card == True,
                              Board[i.BoardX+(i.BoardY*4)] == True)
                        new = luckyBlock("neutral", "green",
                                         i.BoardX, i.BoardY)
                        i.card = True
            return True
        return False
