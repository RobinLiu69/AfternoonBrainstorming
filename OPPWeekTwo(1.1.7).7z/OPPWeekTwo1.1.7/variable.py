import pygame
pygame.init()
Board = []
player1 = []
player2 = []
neutral = []
displayCardW = []
displayCardR = []
displayCardG = []
displayCardB = []
displayCardO = []
displayCardP = []
player1Deck = []
player2Deck = []
player1Trash = []
player2Trash = []
player1Hand = []
player2Hand = []
P1Token = [0]
P2Token = [0]
p1atk = [1]
p2atk = [0]
P1Cube = [0]
P2Cube = [0]
P1Move = [0]
P2Move = [0]
P1Heal = [0]
P2Heal = [0]
P1Luck = [50]
P2Luck = [50]
P1DrawCard = [0]
P2DrawCard = [0]
display_info= pygame.display.get_desktop_sizes()
display_width = display_info[0][0]/2560*2600
display_height = (display_width*15)/26
blocksize = display_height/6
gameDisplay = pygame.display.set_mode(
    (display_width, display_height), pygame.FULLSCREEN)

text_font = pygame.font.Font("8bitOperatorPlus-Bold.ttf", int(display_width/1500*15))
big_text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/1500*25))
small_text_font = pygame.font.Font("8bitOperatorPlus-Bold.ttf", int(display_width/1500*8.66))
