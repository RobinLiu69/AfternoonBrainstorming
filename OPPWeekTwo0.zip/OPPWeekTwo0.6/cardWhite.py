from variable import Board, player1, player2, neutral, displayCardW, display_height, display_width, blocksize, player1Trash, player2Hand, player1Hand, player2Trash, P1Cube, P2Cube, P1Heal, P2Heal, P1Move, P2Move
import random
import pygame
print("import pygame")
pygame.init()
print("init")

text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/display_height*15))
small_text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/display_height*8.66))


def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


class cards:
    def __init__(self, owner, type, health, attack, x, y):
        self.owner = owner
        self.originalAttack = attack
        self.attack = attack
        self.health = health
        self.maxHeart = health
        self.canATK = True
        self.x = x
        self.y = y
        self.Board = x+(y*4)
        self.BoardX = x
        self.BoardY = y
        self.moving = False
        self.armor = 0
        self.type = type
        if self.type == "ASSW":
            self.canATK = True
        else:
            self.canATK = False
        if owner == "player1":
            player1.append(self)
        elif owner == "player2":
            player2.append(self)
        elif owner == "neutral":
            neutral.append(self)
        elif owner == "display":
            self.canATK = True
            displayCardW.append(self)

    def move(self, x, y):
        ed = 0
        if Board[x+(y*4)].card == False:
            print(((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y)
                  == 0 and abs(self.x-x) == 1)), (self.y != y or self.x != x), self.moving == True)
            if ((abs(self.y-y) == 1 and (abs(self.x-x) == 1 or abs(self.x-x) == 0)) or (abs(self.y-y) == 0 and abs(self.x-x) == 1)) and (self.y != y or self.x != x) and self.moving == True:
                ed = 0
            else:
                ed = 1
            if ed == 1:
                self.moving = False
                return False
            if ed == 0:
                Board[self.x+(self.y*4)].card = False
                self.x = x
                self.BoardX = x
                self.y = y
                self.BoardY = y
                self.Board = x+(y*4)
                Board[self.x+(self.y*4)].card = True
                self.moving = False
                if self.owner=="player2":
                    for i in player1:
                        if i.type=="TANKP":
                            self.damage(2,i)
                if self.owner=="player1":
                    for i in player2:
                        if i.type=="TANKP":
                            self.damage(2,i)
                return True
        self.moving = False
        return False

    def beenAttack(self, attacker):
        if attacker.type == "APR":
            if self.attack >= 1:
                attacker.attack += 1
                attacker.SPAdd("attack", 1)
                self.attack -= 1

    def Kill(self):
        return True

    def damage(self, value, dieTo):
        if value == 0:
            return True
        if self.armor > 0 and self.armor >= value:
            self.armor -= value
            self.beenAttack(dieTo)
            return True
        elif self.armor > 0 and self.armor < value:
            value = self.armor-value
            self.armor = 0
            self.health += value
            self.beenAttack(dieTo)
            return True
        elif self.armor == 0:
            self.health -= value
            self.beenAttack(dieTo)
            if self.health <= 0:
                dieTo.Kill()
            return True
        return False

    def heal(self, value):
        if self.health+value <= self.maxHeart:
            self.health += value
            return True
        elif self.health+value > self.maxHeart and self.health < self.maxHeart:
            self.health = self.maxHeart
            return True
        return False

    def displayText(self, screen):
        drawText("HP:"+str(self.health), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        drawText("ATK:"+str(self.attack), text_font, self.color,
                 (display_width/3.2)+(self.x*blocksize)+(display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/20), screen)
        if self.owner != "display":
            drawText(str(self.owner), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        else:
            drawText(str(self.type), text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)+(display_height/12.5), screen)
        if self.canATK == False:
            drawText("numbness", small_text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/18), (display_height/3.529)+(self.y*blocksize)+(display_height/10.714), screen)
        if self.armor >= 1:
            drawText("arm:"+str(self.armor), small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/((blocksize*4)/5)), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)
        if self.moving == True:
            drawText("Moving", small_text_font, self.color,  (display_width/3.2)+(self.x*blocksize) +
                     (display_width/20), (display_height/3.529)+(self.y*blocksize)-(display_height/30), screen)

    def Attack(self, type, time, turn):
        if self.canATK == True:
            ed = 0
            if "cross" in type:
                ed = 0
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX and i.BoardY == self.BoardY+1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "x" in type:
                ed = 0
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY+1) or (i.BoardX == self.BoardX-1 and i.BoardY == self.BoardY-1) or (i.BoardX == self.BoardX+1 and i.BoardY == self.BoardY-1):
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "Bigx" in type:
                ed = 0
                if turn == "player1":
                    for i in player2:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if turn == "player2":
                    for i in player1:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                    for i in neutral:
                        if (i.BoardX == self.BoardX or i.BoardY == self.BoardY) and i.Board != self.Board:
                            # print("attck")
                            i.damage(self.attack, self)
                            self.ability(i, turn)
                            ed = 1
                if ed == 1 and len(type) == 1:
                    return True
            if "nearest" in type:
                Min = []
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        print(neutral)
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if "farest" in type:
                Min = []
                # min暫代最遠
                if turn == "player1":
                    if len(player2) >= 1:
                        Min = [player2[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player2:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        print(neutral)
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                if turn == "player2":
                    if len(player1) >= 1:
                        Min = [player1[0]]
                    elif len(neutral) >= 1:
                        Min = [neutral[0]]
                    for i in player1:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    for i in neutral:
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) > abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min = [i]
                        if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY):
                            Min.append(i)
                    if len(Min) > 1 and len(type) == 1:
                        i = random.randint(0, len(Min)-1)
                        Min[i].damage(self.attack, self)
                        self.ability(Min[i], turn)
                        return True
                    elif len(Min) == 1 and len(type) == 1:
                        Min[0].damage(self.attack, self)
                        self.ability(Min[0], turn)
                        return True
            if time >= 1 and ed == 1:
                return True
        else:
            return False


def playCardWhite(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPW":
                new = SP("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTW":
                new = APT("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APW":
                new = AP("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCW":
                new = ADC("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKW":
                new = TANK("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFW":
                new = heavyFighter("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFW":
                new = lightFighter("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSW":
                new = ASS("player1", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True

        if card == "CUBE":
            print(f"P1cube{P1Cube}")
            P1Cube[0] += 2
            print(P1Cube)
            tag = 1
        if card == "HEAL":
            P1Heal[0] += 1
            tag = 1
        if card == "MOVE":
            P1Move[0] += 1
            tag = 1
        if tag == 1:
            player1Trash.append(card)
            player1Hand.remove(card)
            return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPW":
                new = SP("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTW":
                new = APT("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APW":
                new = AP("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCW":
                new = ADC("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKW":
                new = TANK("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFW":
                new = heavyFighter("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFW":
                new = lightFighter("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSW":
                new = ASS("player2", "white", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
        if card == "CUBE":
            P2Cube[0] += 2
            tag = 1
        if card == "HEAL":
            P2Heal[0] += 1
            tag = 1
        if card == "MOVE":
            P2Move[0] += 1
            tag = 1
        if tag == 1:
            player2Trash.append(card)
            player2Hand.remove(card)
            return True
    return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "TANKW", 15, 1, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class cube(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "cube", 4, 0, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+37.5+(display_width/40), (display_height/3.529)+(self.y*blocksize)+37.5, 25, 25), 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return False


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "ADCW", 5, 4, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["Bigx"], 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "ASSW", 2, 5, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["x"], 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "APW", 4, 3, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize)+50+(
            display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.displayText(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        return True

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "HFW", 9, 2, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross", "x"], 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "LFW", 7, 3, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "SPW", 1, 5, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x *
                                                                                                                                                                                                                                                                                           blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.displayText(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["farest"], 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "white":
            super().__init__(owner, "APTW", 8, 2, x, y)
            color = (255, 255, 255)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.displayText(screen)

    def ability(self, enemy, turn):
        if turn == "player1":
            Min = []
            if len(player1) > 1:
                for i in player1:
                    if i != self:
                        Min = [i]
                        break
            elif len(player1) == 1:
                self.armor += 2
                return True
            for i in player1:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        elif turn == "player2":
            Min = []
            if len(player2) > 1:
                for i in player2:
                    if i != self:
                        Min = [i]
                        break
            elif len(player2) == 1:
                self.armor += 2
                return True
            for i in player2:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 2
                Min[i].armor += 2
                return True
            elif len(Min) == 1:
                self.armor += 2
                Min[0].armor += 2
                return True
        return False

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)
