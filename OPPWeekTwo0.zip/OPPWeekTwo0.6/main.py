
from variable import Board, player1, player2, neutral, player1Deck, player2Deck, display_width, display_height, player1Hand, player1Trash, player2Hand, player2Trash, gameDisplay, P1Cube, P2Cube, P1Heal, P2Heal, P1Move, P2Move, P1Luck, P2Luck, P1Token, P2Token, p1atk, p2atk, P1DrawCard, P2DrawCard, P1totemHP, P2totemHP, P1totemAD, P2totemAD
import pygame
import random
import cardGreen as cG
import cardRed as cR
import cardWhite as cW
import cardBlue as cB
import cardOrange as cO
import cardPurple as cP
import cardDKGreen as cDKG
exec(open("start.py").read())


pygame.init()

pygame.display.set_caption('THE CARD GAME!!')

black = (0, 0, 0)
white = (255, 255, 255)
clock = pygame.time.Clock()
run = True
text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/display_height*15))
small_text_font = pygame.font.Font(
    "8bitOperatorPlus-Bold.ttf", int(display_width/display_height*8.66))
canSee = True


def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))


def displayHand(screen):
    for i in range(0, len(player1Hand)):
        if i < 9:
            if player1Hand[i] == "MOVEO":
                drawText("P1hand " + str(i+1) + " :"+player1Hand[i], text_font, (255, 69, 0), display_width/2-(
                    display_width/3), display_height/15*(i+1), screen)
            else:
                drawText("P1hand " + str(i+1) + " :"+player1Hand[i], text_font, (255, 255, 255), display_width/2-(
                    display_width/3), display_height/15*(i+1), screen)
        if i == 9:
            if player1Hand[i] == "MOVEO":
                drawText("P1hand " + str(0) + " :"+player1Hand[i], text_font, (255, 69, 0), display_width/2-(
                    display_width/3), display_height/15*(i+1), screen)
            else:
                drawText("P1hand " + str(0) + " :"+player1Hand[i], text_font, (255, 255, 255), display_width/2-(
                    display_width/3), display_height/15*(i+1), screen)
        if i == 10:
            drawText("P1hand " + "key.u" + " :"+player1Hand[i], text_font, (255, 255, 255), display_width/2-(
                display_width/3), display_height/15*(i+1), screen)
        if i == 11:
            drawText("P1hand " + "key.i" + " :"+player1Hand[i], text_font, (255, 255, 255), display_width/2-(
                display_width/3), display_height/15*(i+1), screen)

    for i in range(0, len(player2Hand)):
        if i < 9:
            if player2Hand[i] == "MOVEO":
                drawText("P2hand " + str(i+1) + " :"+player2Hand[i], text_font, (255, 69, 0), display_width/2+(
                    display_width/4), display_height/15*(i+1), screen)
            else:
                drawText("P2hand " + str(i+1) + " :"+player2Hand[i], text_font, (255, 255, 255), display_width/2+(
                    display_width/4), display_height/15*(i+1), screen)
        if i == 9:
            if player2Hand[i] == "MOVEO":
                drawText("P2hand " + str(0) + " :"+player2Hand[i], text_font, (255, 69, 0), display_width/2+(
                    display_width/4), display_height/15*(i+1), screen)
            else:
                drawText("P2hand " + str(0) + " :"+player2Hand[i], text_font, (255, 255, 255), display_width/2+(
                    display_width/4), display_height/15*(i+1), screen)
        if i == 10:
            drawText("P2hand " + "key.u" + " :"+player2Hand[i], text_font, (255, 255, 255), display_width/2+(
                display_width/4), display_height/15*(i+1), screen)
        if i == 11:
            drawText("P2hand " + "key.i" + " :"+player2Hand[i], text_font, (255, 255, 255), display_width/2+(
                display_width/4), display_height/15*(i+1), screen)


def drawCard(turn):
    global player1Deck, player2Deck, player1Trash, player2Trash, player1Hand, player2Hand
    if turn == "player1":
        if len(player1Deck) == 0:
            for i in range(0, len(player1Trash)):
                a = random.randint(0, len(player1Trash)-1)
                player1Deck.append(player1Trash[a])
                player1Trash.pop(a)
        if len(player1Deck) > 0:
            a = player1Deck[random.randint(0, len(player1Deck)-1)]
            player1Hand.append(a)
            player1Deck.remove(a)
        return True
    elif turn == "player2":
        if len(player2Deck) == 0:
            for i in range(0, len(player2Trash)):
                a = random.randint(0, len(player2Trash)-1)
                player2Deck.append(player2Trash[a])
                player2Trash.pop(a)
        if len(player2Deck) > 0:
            a = player2Deck[random.randint(0, len(player2Deck)-1)]
            player2Hand.append(a)
            player2Deck.remove(a)
        return True
    return False


def playCard(turn, card):
    if cW.playCardWhite(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cR.playCardRed(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cG.playCardGreen(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cB.playCardBlue(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cO.playCardOrange(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cP.playCardPurple(turn, card, BX, BY, mouseX, mouseY):
        return True
    if cDKG.playCardDKGreen(turn, card, BX, BY, mouseX, mouseY):
        return True
    return False


class boardSpawn:
    def __init__(self, x, y, width, height, card, color, BX, BY):
        self.type = "Board"
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.card = card
        self.size = width
        self.color = color
        self.BoardX = BX
        self.BoardY = BY
        self.Board = BX+(BY*4)
        self.thickness = 2
        Board.append(self)

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         (self.x, self.y, self.width, self.height), 4)


class changeTurn:
    def __init__(self, x, y, width, height, color):
        self.type = "Board"
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.size = width
        self.color = color
        self.thickness = 2

    def display(self, screen):
        global turn, player1, player2
        pygame.draw.rect(screen, self.color,
                         (self.x, self.y, self.width, self.height), 4)
        drawText("End turn", text_font, self.color,
                 display_width/2-65, display_height/5-45, screen)
        if turn == "player1":
            drawText("Player1", text_font, self.color,
                     display_width/2-50, display_height/5-10, screen)
        elif turn == "player2":
            drawText("Player2", text_font, self.color,
                     display_width/2-50, display_height/5-10, screen)


score = 0

x = display_width/2-(display_width/10.4*2)
y = display_height/2-(display_height/3.75)

for i in range(4):
    x = display_width/2-(display_width/10.4*2)
    for ii in range(4):
        BX = int((x-(display_width/3.25))/(display_width/10.4))
        BY = int((y-(display_height/4.2858))/(display_width/10.4))
        new = boardSpawn(x, y, (display_width/10.4),
                         (display_width/10.4), False, white, BX, BY)
        x += (display_width/10.4)
    y += (display_width/10.4)
Button = changeTurn(display_width/2-100, display_height /
                    5-50, 200, 100, (200, 200, 200))
canA = True
canE = True
canH = True
canM = True
can1 = True
can2 = True
can3 = True
can4 = True
can5 = True
can6 = True
can7 = True
can8 = True
can9 = True
can0 = True
canU = True
canI = True
turn = "player1"
clock = pygame.time.Clock()


for i in range(0, 3):
    drawCard("player1")
    drawCard("player2")
while run:
    if P1DrawCard[0] >= 1:
        drawCard("player1")
        P1DrawCard[0] -= 1
    if P2DrawCard[0] >= 1:
        drawCard("player2")
        P2DrawCard[0] -= 1
    gameDisplay.fill(black)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
    mouseX, mouseY = pygame.mouse.get_pos()
    BX = int((mouseX-(display_width/3.25))/(display_width/10.4))
    BY = int((mouseY-(display_height/4.2858))/(display_width/10.4))
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        run = False
    if keys[pygame.K_e] and canE == True:
        if turn == "player1":
            score -= len(player1)
            for i in player1:
                if i.type == "HFO":
                    i.Maction("player2")
                if i.canATK == False:
                    score += 1
                    i.canATK = True
                elif i.type == "SPW":
                    score -= 1
                i.moving = False
            if len(player1Hand) >= 1:
                n = 1
                for i in range(0, len(player1Hand)):
                    if player1Hand[i] == "MOVEO":
                        n += 1
                for o in (0, n):
                    for i in range(0, len(player1Hand)):
                        if player1Hand[i] == "MOVEO":
                            playCard(turn, player1Hand[i])
                            P1Move[0] = 0
                            break
            for i in player2:
                i.moving = False
            if score <= -10:
                print("Player1 Win")
                run = False
            drawCard("player2")
            P1Heal[0] = 0
            P1Cube[0] = 0
            P1Move[0] = 0
            p2atk[0] += 1
            for i in player2:
                if i.type == "APO":
                    i.Maction(i.owner)
                if i.type == "HFDKG":
                    i.damage(2, i)
                    i.toteming(2)
            turn = "player2"
        elif turn == "player2":
            score += len(player2)
            for i in player2:
                if i.type == "HFO":
                    i.Maction("player1")
                if i.canATK == False:
                    score -= 1
                    i.canATK = True
                elif i.type == "SPW":
                    score += 1
                i.moving = False
            if len(player2Hand) >= 1:
                n = 1
                for i in range(0, len(player2Hand)):
                    if player2Hand[i] == "MOVEO":
                        n += 1
                for o in (0, n):
                    for i in range(0, len(player2Hand)):
                        if player2Hand[i] == "MOVEO":
                            playCard(turn, player2Hand[i])
                            P2Move[0] = 0
                            break
            for i in player1:
                i.moving = False
            if score >= 10:
                print("Player2 Win")
                run = False
            drawCard("player1")
            P2Heal[0] = 0
            P2Cube[0] = 0
            P2Move[0] = 0
            p1atk[0] += 1
            for i in player1:
                if i.type == "APO":
                    i.Maction(i.owner)
                if i.type == "HFDKG":
                    i.damage(2, i)
                    i.toteming(2)
            turn = "player1"
        canE = False
    elif not keys[pygame.K_e] and canE == False:
        canE = True

    displayHand(gameDisplay)
    if keys[pygame.K_p]:
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858):
            if Board[BX+(BY*4)].card == False:
                print("spawn")
                if turn == "player1" and P1Cube[0] >= 1:
                    new = cW.cube("neutral", "white", BX, BY)
                    P1Cube[0] -= 1
                    Board[BX+(BY*4)].card = True
                if turn == "player2" and P2Cube[0] >= 1:
                    new = cW.cube("neutral", "white", BX, BY)
                    P2Cube[0] -= 1
                    Board[BX+(BY*4)].card = True

    if keys[pygame.K_h] and canH == True:
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858):
            if Board[BX+(BY*4)].card == True:
                print("heal")
                if turn == "player1" and P1Heal[0] >= 1:
                    for i in player1:
                        if i.Board == BX+(BY*4):
                            if i.heal(3):
                                P1Heal[0] -= 1
                if turn == "player2" and P2Heal[0] >= 1:
                    for i in player2:
                        if i.Board == BX+(BY*4):
                            if i.heal(3):
                                P2Heal[0] -= 1
        canH = False
    elif not keys[pygame.K_h] and canH == False:
        canH = True
    if keys[pygame.K_m] and canM == True:
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858):
            tag = 0
            if turn == "player1":
                for i in player1:
                    if i.moving == True:
                        tag = i
                        break
            if turn == "player2":
                for i in player2:
                    if i.moving == True:
                        tag = i
                        break
            if Board[BX+(BY*4)].card == True and (P1Move[0] >= 1 or P2Move[0] >= 1):
                if tag == 0:
                    print("Move")
                    if turn == "player1":
                        for i in player1:
                            if i.Board == BX+(BY*4) and i.canATK == True:
                                i.moving = True
                                P1Move[0] -= 1
                                break
                    elif turn == "player2":
                        for i in player2:
                            if i.Board == BX+(BY*4) and i.canATK == True:
                                i.moving = True
                                P2Move[0] -= 1
                                break
            if Board[BX+(BY*4)].card == False:
                if tag != 0:
                    print("press")
                    i.move(BX, BY)
        canM = False
    elif not keys[pygame.K_m] and canM == False:
        canM = True
    if keys[pygame.K_1] and can1 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 1:
                playCard(turn, player1Hand[0])
        if turn == "player2":
            if len(player2Hand) >= 1:
                playCard(turn, player2Hand[0])
        can1 = False
    elif not keys[pygame.K_1] and can1 == False:
        can1 = True
    if keys[pygame.K_2] and can2 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 2:
                playCard(turn, player1Hand[1])
        if turn == "player2":
            if len(player2Hand) >= 2:
                playCard(turn, player2Hand[1])
        can2 = False
    elif not keys[pygame.K_2] and can2 == False:
        can2 = True
    if keys[pygame.K_3] and can3 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 3:
                playCard(turn, player1Hand[2])
        if turn == "player2":
            if len(player2Hand) >= 3:
                playCard(turn, player2Hand[2])
        can3 = False
    elif not keys[pygame.K_3] and can3 == False:
        can3 = True
    if keys[pygame.K_4] and can4 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 4:
                playCard(turn, player1Hand[3])
        if turn == "player2":
            if len(player2Hand) >= 4:
                playCard(turn, player2Hand[3])
        can4 = False
    elif not keys[pygame.K_4] and can4 == False:
        can4 = True
    if keys[pygame.K_5] and can5 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 5:
                playCard(turn, player1Hand[4])
        if turn == "player2":
            if len(player2Hand) >= 5:
                playCard(turn, player2Hand[4])
        can5 = False
    elif not keys[pygame.K_5] and can5 == False:
        can5 = True
    if keys[pygame.K_6] and can6 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 6:
                playCard(turn, player1Hand[5])
        if turn == "player2":
            if len(player2Hand) >= 6:
                playCard(turn, player2Hand[5])
        can6 = False
    elif not keys[pygame.K_6] and can6 == False:
        can6 = True
    if keys[pygame.K_7] and can7 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 7:
                playCard(turn, player1Hand[6])
        if turn == "player2":
            if len(player2Hand) >= 7:
                playCard(turn, player2Hand[6])
        can7 = False
    elif not keys[pygame.K_7] and can7 == False:
        can7 = True
    if keys[pygame.K_8] and can8 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 8:
                playCard(turn, player1Hand[7])
        if turn == "player2":
            if len(player2Hand) >= 8:
                playCard(turn, player2Hand[7])
        can8 = False
    elif not keys[pygame.K_8] and can8 == False:
        can8 = True
    if keys[pygame.K_9] and can9 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 9:
                playCard(turn, player1Hand[8])
        if turn == "player2":
            if len(player2Hand) >= 9:
                playCard(turn, player2Hand[8])
        can9 = False
    elif not keys[pygame.K_9] and can9 == False:
        can0 = True
    if keys[pygame.K_0] and can0 == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 10:
                playCard(turn, player1Hand[9])
        if turn == "player2":
            if len(player2Hand) >= 10:
                playCard(turn, player2Hand[9])
        can0 = False
    elif not keys[pygame.K_0] and can0 == False:
        can0 = True
    if keys[pygame.K_u] and canU == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 11:
                playCard(turn, player1Hand[10])
        if turn == "player2":
            if len(player2Hand) >= 11:
                playCard(turn, player2Hand[10])
        canU = False
    elif not keys[pygame.K_u] and canU == False:
        canU = True
    if keys[pygame.K_i] and canI == True:
        print("spawn")
        if turn == "player1":
            if len(player1Hand) >= 12:
                playCard(turn, player1Hand[11])
        if turn == "player2":
            if len(player2Hand) >= 12:
                playCard(turn, player2Hand[11])
        canI = False
    elif not keys[pygame.K_i] and canI == False:
        canI = True
    if keys[pygame.K_a] and canA == True:
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858):
            if turn == "player1" and p1atk[0] >= 1:
                for i in player1:
                    if i.Board == BX+(BY*4) and i.owner == "player1":
                        if i.atk(turn):
                            p1atk[0] -= 1
            elif turn == "player2" and p2atk[0] >= 1:
                for i in player2:
                    if i.Board == BX+(BY*4) and i.owner == "player2":
                        if i.atk(turn):
                            p2atk[0] -= 1
            canA = False
    elif not keys[pygame.K_a] and canA == False:
        canA = True
    if keys[pygame.K_o]:
        new = cO.ASS("player1", "orange", BX, BY)
    for i in Board:
        i.display(gameDisplay)

    for i in player1:
        if i.health <= 0:
            if i.type == "SPG":
                if i.owner == "player1":
                    P1Luck[0] -= 15
                if i.owner == "player2":
                    P2Luck[0] -= 15
            player1Trash.append(i.type)
            Board[i.Board].card = False
            player1.remove(i)
            i = 0
            continue
        i.display(gameDisplay)
    for i in player2:
        if i.health <= 0:
            player2Trash.append(i.type)
            Board[i.Board].card = False
            player2.remove(i)
            i = 0
            continue
        i.display(gameDisplay)
    for i in neutral:
        if i.health <= 0:
            Board[i.Board].card = False
            neutral.remove(i)
            i = 0
            continue
        i.display(gameDisplay)
    if score <= 0:
        drawText("P1score:"+str(abs(score)), text_font, (255, 255, 255),
                 display_width/2-(display_width/9), display_height/5.5, gameDisplay)
        drawText("P2score:"+str(0), text_font, (255, 255, 255),
                 display_width/2+(display_width/18), display_height/5.5, gameDisplay)
    if score > 0:
        drawText("P1score:"+str(0), text_font, (255, 255, 255),
                 display_width/2-(display_width/9), display_height/5.5, gameDisplay)
        drawText("P2score:"+str(score), text_font, (255, 255, 255),
                 display_width/2+(display_width/18), display_height/5.5, gameDisplay)
    drawText("P1ATK:"+str(p1atk[0]), text_font, (255, 255, 255),
             display_width/2-(display_width/6), display_height/5.5, gameDisplay)
    drawText("P2ATK:"+str(p2atk[0]), text_font, (255, 255, 255),
             display_width/2+(display_width/8), display_height/5.5, gameDisplay)
    drawText("P1Luck:"+str(P1Luck[0])+"%", text_font, (51, 255, 51),
             display_width/2-(display_width/6), display_height/5, gameDisplay)
    drawText("P2Luck:"+str(P2Luck[0])+"%", text_font, (51, 255, 51),
             display_width/2+(display_width/8), display_height/5, gameDisplay)
    drawText("P1TOKEN:" + str(P1Token[0]), text_font, (60, 100, 225),
             display_width/2-(display_width/4.25), display_height/5.5, gameDisplay)
    drawText("P2TOKEN:" + str(P2Token[0]), text_font, (60, 100, 225),
             display_width/2+(display_width/5.5), display_height/5.5, gameDisplay)
    drawText(str(P1totemHP[0])+"/"+str(P1totemAD[0]), text_font, (85, 107, 47),
             display_width/2-(display_width/6), display_height/6.3, gameDisplay)
    drawText(str(P2totemHP[0])+"/"+str(P2totemAD[0]), text_font, (85, 107, 47),
             display_width/2+(display_width/6), display_height/6.3, gameDisplay)
    if P1Token[0] >= 4:
        P1Token[0] -= 4
        drawCard("player1")
        for i in player1:
            if i.type == "ADCB":
                i.atk(i.owner)
    if P2Token[0] >= 4:
        P2Token[0] -= 4
        drawCard("player2")
        for i in player2:
            if i.type == "ADCB":
                i.atk(i.owner)
    Button.display(gameDisplay)
    pygame.display.update()
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
quit()
