import pygame
import socket
import threading

pygame.init()

pygame.mixer.init()

def play_sound(frequency):
    sound = pygame.mixer.Sound(frequency)
    sound.set_volume(100)
    sound.play()

def receive_data(client_socket):
    global message
    try:
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            if data.decode('utf-8') != message:
                print(f"{data.decode('utf-8')}")
                play_sound(440)
    except:
        pass

    client_socket.close()

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('25.36.126.26', 12345)
client_socket.connect(server_address)

receive_thread = threading.Thread(target=receive_data, args=(client_socket,))
receive_thread.start()

try:
    login_message = input("请输入用户名：")
    while True:
        message = login_message + ":" + input("")
        if message.strip(): 
            try:
                client_socket.sendall(message.encode('utf-8'))
            except OSError as e:
                print("发送数据时出现错误:", e)
                break
except KeyboardInterrupt:
    print("客户端關閉")
finally:
    client_socket.close()
