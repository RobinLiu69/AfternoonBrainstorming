from variable import *
from calculate import update_data
from card import cards
import pygame
pygame.init()

def playCardDKGreen(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPDKG":
                new = SP("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTDKG":
                new = APT("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APDKG":
                new = AP("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCDKG":
                new = ADC("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKDKG":
                new = TANK("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFDKG":
                new = heavyFighter("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFDKG":
                new = lightFighter("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSDKG":
                new = ASS("player1", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPDKG":
                new = SP("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTDKG":
                new = APT("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APDKG":
                new = AP("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCDKG":
                new = ADC("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKDKG":
                new = TANK("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFDKG":
                new = heavyFighter("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFDKG":
                new = lightFighter("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSDKG":
                new = ASS("player2", "DKGreen", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
    return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "TANKDKG", 9, 1, x, y)
            color = (85, 107, 47)
            self.color = color


    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)
class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "ADCDKG", 4, 2, x, y)
            color = (85, 107, 47)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        self.toteming(1)
        return True

    def atk(self, turn):
        return self.Attack(["Bigx"], 1, turn)


class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "ASSDKG", 2, 4, x, y)
            color = (85, 107, 47)
            self.color = color
            self.D = 0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        
        if self.D==1:
            self.toteming(6)
            self.health=0
        
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["x"], 1, turn)


class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "APDKG", 4, 0, x, y)
            color = (85, 107, 47)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize)+50+(
            display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        return True

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)
        

class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "HFDKG", 8, 2, x, y)
            color = (85, 107, 47)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        self.heal(1)
        return True

    def atk(self, turn):
        return self.Attack(["cross", "x"], 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "LFDKG", 6, 3, x, y)
            color = (85, 107, 47)
            self.color = color
            if owner=="player1":
                for i in player2:
                    self.toteming(1)
            if owner=="player2":
                for i in player1:
                    self.toteming(1)

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "SPDKG", 1, 3, x, y)
            color = (85, 107, 47)
            self.color = color
            if owner=="player1":
                if P1totemHP[0]>=2:
                    self.armor+=int(P1totemHP[0]-1)
                    P1totemHP[0]=0
                if P1totemAD[0]>=2:
                    self.attack+=int(P1totemAD[0])
                    P1totemAD[0]=0
            if owner=="player2":
                if P2totemHP[0]>=2:
                    self.armor+=int(P2totemHP[0]-1)
                    P2totemHP[0]=0
                if P2totemAD[0]>=2:
                    self.attack+=int(P2totemAD[0])
                    P2totemAD[0]=0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x *
                                                                                                                                                                                                                                                                                           blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["farest"], 1, turn)


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "DKGreen":
            super().__init__(owner, "APTDKG", 2, 2, x, y)
            color = (85, 107, 47)
            self.color = color
            if owner=="player1":
                self.armor+=int(P1totemHP[0]/2)
            if owner=="player2":
                self.armor+=int(P2totemHP[0]/2)

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        return False

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)
