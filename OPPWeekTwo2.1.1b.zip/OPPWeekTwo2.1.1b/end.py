from variable import *
from calculate import makebarchart, makepiechart, makeplot
import os, sys
import pygame
import concurrent.futures

white = (255, 255, 255)
black = (0, 0, 0)
run = True

loading_font = pygame.font.Font(None, 36)
loading_text = loading_font.render("Loading...", True, "white")
loading_animation = 0

code_path = os.getcwd()


def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))

display = []

class Object:
    def __init__(self, type, x, y, width, height, visule):
        self.type = type
        self.x = x
        self.y = y
        self.width = int(width)
        self.height = int(height)
        self.visule = visule
        display.append(self)

class Piechart(Object):
    def __init__(self, player, part, x, y):
        super().__init__('piechart', x, y, display_width/5, display_width/5, False)
        self.player = player
        self.part = part
        file_path = os.path.join(code_path, f'output/P{player}-{part}piechart.png')
        if os.path.exists(file_path):
            self.img = pygame.transform.scale(pygame.image.load(file_path).convert_alpha(), ( self.width, self.height ))
        else:
            self.img = None
    def draw(self, screen):
        if self.visule == True and self.img!= None:
            screen.blit(self.img, (self.x, self.y))

class Plotchart(Object):
    def __init__(self, x, y):
        super().__init__('plotchart', x, y, display_width/30*20, display_width/30*8, True)
        file_path = os.path.join(code_path, f'output/plotchart.png')
        if os.path.exists(file_path):
            self.img = pygame.transform.scale(pygame.image.load(file_path).convert_alpha(), ( self.width, self.height ))
        else:
            self.img = None
    def draw(self, screen):
        if self.visule == True and self.img!= None:
            screen.blit(self.img, (self.x, self.y))

class Barchart(Object):
    def __init__(self, player, part, x, y):
        super().__init__('barchart', x, y, display_width/6, display_width/6, False)
        self.player = player
        self.part = part
        file_path = os.path.join(code_path, f'output/P{player}-{part}barchart.png')
        if os.path.exists(file_path):
            self.img = pygame.transform.scale(pygame.image.load(file_path).convert_alpha(), ( self.width, self.height ))
        else:
            self.img = None
    def draw(self, screen):
        if self.visule == True and self.img!= None:
            screen.blit(self.img, (self.x, self.y))

buttons = []

class Button(Object):
    def __init__(self, x, y, width, height, text, text_size, text_color, bg_color, action, player):
        super().__init__('button', x, y, width, height, True)
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.player = player
        self.text_size = int(text_size)
        self.text_color = text_color
        self.bg_color = bg_color
        self.action = action
        buttons.append(self)

    def draw(self, screen):
        if self.visule == True:
            pygame.draw.rect(screen, self.bg_color, self.rect)
            text_surface = text_font.render(self.text, True, self.text_color)
            text_rect = text_surface.get_rect(center=self.rect.center)
            screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                if self.action:
                    self.action(self, self.player)
last_time = 0
wait_time = 0
countdown = 0
def playerDisplay(self, player):
    global last_time, countdown
    if countdown == 0:
        for i in range(len(display)):
            if display[i].type == "button" and display[i]!=self:
                if display[i].bg_color == (50, 50, 50):
                    return False  
        for i in display:
            if i.type == "barchart":
                if i.player == player:
                    if i.visule == False:
                        i.visule = True
                        self.bg_color = (50, 50, 50)
                    else:
                        i.visule = False
                        self.bg_color = (0, 0, 0)
            if i.type == "plotchart":
                if i.visule == False:
                    i.visule = True
                else:
                    i.visule = False
        for i in display:
            if i.type == "piechart":
                if i.player == player:
                    if i.visule == False:
                        countdown = 4
                        last_time = pygame.time.get_ticks()
                        self.bg_color = (50, 50, 50)
                        return True
                    else:
                        i.visule = False
                        self.bg_color = (0, 0, 0)
        return True
    return False

def exit(self, player):
    global run
    run = False
    return True
def makeimg():
    for i in range(1,5):
        makebarchart(P1matrix, i, "P1-")
        Barchart(1, i, display_width/13*i*2.25, display_height/3*3*0.7)
        makebarchart(P2matrix, i, "P2-")
        Barchart(2, i, display_width/13*i*2.25, display_height/3*3*0.7)
        makepiechart(P1matrix, i, "P1-")
        Piechart(1, i, display_width/30*i*6-display_width*0.08, display_height/3*i*0.25)
        makepiechart(P2matrix, i, "P2-")
        Piechart(2, i, display_width/30*i*6-display_width*0.08, display_height/3*i*0.25)
        print(f"makeing:{i}")
    makeplot(TimeLine)
    Plotchart(display_width/13*2.25, display_height/3*3*0.55)
    print("makeTimeLine")
    return True


button1 = Button(display_width/10*2, display_height/10*5, 100, 50, "P1", text_font_size*1.5, white, black, playerDisplay, 1)
button2 = Button(display_width/10*3, display_height/10*5, 100, 50, "P2", text_font_size*1.5, white, black, playerDisplay, 2)
button3 = Button(display_width/10*4, display_height/10*5, 100, 50, "esc", text_font_size*1.5, white, black, exit, None)

mouse_clicked = False

time_delay = 75

loading_text = "Loading"
loading_animation = 0

waiting = True
clock = pygame.time.Clock()
loading_x = display_width/2*0.9

def waitscreen():
    global loading_text, loading_animation, waiting, loading_animation, loading_x, wait_time, display_width, display_height
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        gameDisplay.fill(black)
        wait_time += 1
        if wait_time > 100:
            loading_x = display_width/3*1.2
            loading_text = "Error:Runtimeout"
            if wait_time > 125:
                waiting = False
                pygame.quit()
        else:
            if loading_animation <20:
                loading_animation += 1
                loading_x -= loading_animation/15
            else:
                loading_animation = 0
                loading_x = display_width/2*0.9
        drawText(loading_text, big_text_font, white, loading_x, display_height/2, gameDisplay)
        
        if loading_animation == 0:
            loading_text = "Loading"
        if loading_animation == 5:
            loading_text = "Loading."
        if loading_animation == 10:
            loading_text = "Loading.."
        if loading_animation == 15:
            loading_text = "Loading..."
        pygame.display.update()
        clock.tick(10)
def main():
    global waiting, run, countdown, last_time, time_delay, display_width, display_height, P1matrix, P2matrix, TimeLine
    pygame.init()

    print (P1matrix)
    print (P2matrix)
    print (TimeLine)

    if P1matrix == [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數']] and P2matrix == [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數']] and TimeLine == []:
        P1matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['SPB', 1, 9, 1, 2, 2], ['HFDKG', 3, 0, 16, 3, 6], ['ASSDKG', 4, 19, 0, 0, 0], ['SPDKG', 0, 0, 4, 0, 2], ['ASSB', 1, 2, 4, 1, 1], ['TANKB', 0, 0, 7, 0, 3]]
        P2matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['TANKR', 0, 0, 12, 1, 3], ['TANKG', 0, 0, 6, 4, 6], ['ADCR', 4, 10, 3, 7, 3], ['TANKW', 0, 0, 12, 1, 4], ['ASSO', 6, 6, 8, 2, 2]]
        TimeLine = [0, 0, -2, 1, -1, 2, 1, 6, 5, 9, 9, 12]
        
        # P1matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['ADCR', 5, 31, 11, 6, 3], ['ASSR', 4, 10, 10, 7, 2], ['SPR', 5, 20, 9, 9, 3], ['APR', 1, 1, 5, 7, 2], ['TANKR', 0, 0, 5, 17, 1], ['HFR', 0, 0, 15, 8, 3]]
        # P2matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['TANKW', 0, 0, 24, 11, 3], ['ADCW', 0, 0, 14, 1, 3], ['ASSW', 1, 2, 4, 2, 2], ['APW', 4, 10, 4, 4, 2], ['APTW', 0, 0, 27, 12, 4], ['SPW', 7, 28, 16, 8, 4], ['LFW', 2, 6, 18, 2, 4]]
        # TimeLine = [0, 0, 0, 3, -1, 2, 0, 3, 0, 5, 2, 9, 5, 8, 5, 9, 5, 8, 3, 5, -1, 1, -4, -1, -7, -3, -9, -5, -11]


        # 速轉綠射手 vs 幸運綠坦
        # P1Deck:['SPG', 'SPG', 'ADCG', 'ADCG', 'ASSG', 'ASSG', 'TANKG', 'TANKG', 'TANKB', 'TANKB', 'ASSB', 'ASSB']
        # P2Deck:['SPG', 'SPG', 'APTG', 'APTG', 'TANKG', 'TANKG', 'TANKR', 'TANKR', 'ASSW', 'ASSW', 'TANKW', 'TANKW']
        # P1matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['ASSB', 3, 6, 7, 6, 3], ['TANKG', 0, 0, 1, 12, 1], ['SPG', 2, 9, 5, 11, 1], ['TANKB', 1, 2, 10, 10, 2], ['ADCG', 5, 35, 2, 7, 2], ['ASSG', 1, 0, 10, 8, 1]]
        # P2matrix = [['角色', '攻擊次數', '造成傷害', '受到傷害', '得分數', '受到傷害次數'], ['TANKG', 2, 2, 22, 8, 6], ['SPG', 5, 13, 1, 12, 1], ['APTG', 1, 0, 4, 5, 2], ['TANKR', 0, 0, 13, 8, 3], ['ASSW', 2, 3, 8, 2, 2], ['TANKW', 1, 0, 15, 7, 4]]
        # TimeLine = [0, 0, 0, 2, -1, 2, -1, 3, -1, 3, -1, 3, -2, 3, -3, 3, -3, 2, -5, 1, -8, -2, -12]


    
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future = executor.submit(waitscreen)
        makeimg()
        waiting = False
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if not mouse_clicked:
                    mouse_clicked = True
                    for i in buttons:
                        i.handle_event(event)
        if pygame.mouse.get_pressed()[0] == 0:
            mouse_clicked = False
        
        current_time = pygame.time.get_ticks()
        
        if current_time - last_time >= time_delay and countdown > 0:
            player = 0
            for i in range(len(buttons)):
                if buttons[i].bg_color == (50, 50, 50):
                    if buttons[i].player == 1:
                        player = 1
                        break
                    if buttons[i].player == 2:
                        player = 2
                        break
            if player != 0:
                for i in range(len(display)):
                    if display[i].type == "piechart":
                        if display[i].player == player:
                            if display[i].visule == False:
                                countdown -= 1
                                display[i].visule = True
                                last_time = pygame.time.get_ticks()
                                break


        gameDisplay.fill(black)
        # drawText("P1", small_text_font, white, 10, 10, gameDisplay)
        # drawText("P2", small_text_font, white, 10, 30, gameDisplay)
        for i in display:
            i.draw(gameDisplay)
        pygame.display.update()
        clock.tick(60)
    pygame.quit()