from variable import *
from calculate import update_data
from card import cards
import random
import pygame
pygame.init()

def drawText(text, font, textColor, x, y, screen):
    img = font.render(text, True, textColor)
    screen.blit(img, (x, y))

def playCardOrange(turn, card, BX, BY, mouseX, mouseY):
    if turn == "player1":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPO":
                new = SP("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APTO":
                new = APT("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "APO":
                new = AP("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ADCO":
                new = ADC("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "TANKO":
                new = TANK("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "HFO":
                new = heavyFighter("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "LFO":
                new = lightFighter("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
            if card == "ASSO":
                new = ASS("player1", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player1Hand.remove(card)
                return True
        if card == "MOVEO":
            P1Move[0] += 1
            player1Hand.remove(card)

            return True

    elif turn == "player2":
        tag = 0
        if BX <= 3 and BY <= 3 and mouseX > (display_width/3.25) and mouseY > (display_height/4.2858) and Board[BX+(BY*4)].card == False:
            if card == "SPO":
                new = SP("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APTO":
                new = APT("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "APO":
                new = AP("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ADCO":
                new = ADC("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "TANKO":
                new = TANK("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "HFO":
                new = heavyFighter("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "LFO":
                new = lightFighter("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
            if card == "ASSO":
                new = ASS("player2", "orange", BX, BY)
                Board[BX+(BY*4)].card = True
                player2Hand.remove(card)
                return True
        if card == "MOVEO":
            P2Move[0] += 1
            player2Hand.remove(card)
            return True
    return False


class TANK(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "TANKO", 10, 1, x, y)
            color = (255, 69, 0)
            self.color = color

    def display(self, screen):
        pygame.draw.rect(screen, self.color,
                         ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize), 100, 100), 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)


class ADC(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "ADCO", 5, 2, x, y)
            color = (255, 69, 0)
            self.color = color
            self.M = 0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(self.x*blocksize)-10+(
            display_width/40), (display_height/3.529)+(self.y*blocksize)+102), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+102)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if self.M == 0:
            self.M = 1
            self.moving = True
        return True
    
    def Maction(self, turn):
        if self.M == 1:
            self.Attack(["Bigx"], 1, turn)
            self.M = 0
        return True

    def atk(self, turn):
        return self.Attack(["Bigx"], 1, turn)



class ASS(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "ASSO", 2, 4, x, y)
            color = (255, 69, 0)
            self.color = color
            self.M = 0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-10, (display_height/3.529)+(self.y*blocksize)+77),
                      ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+50, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+110, (display_height/3.529)+(self.y*blocksize)+77)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        if self.M == 1:
            drawText("anger", small_text_font, self.color,  (display_width/3.2) +
                     (self.x*blocksize)+(display_width/18), (display_height/3.529)+(self.y*blocksize)+(display_height/10.714), screen)
        self.update(screen)

    def ability(self, enemy, turn):
        self.moving = True
        return True

    def Maction(self, turn):
        if self.M == 0:
            self.M = 1
        return True

    def atk(self, turn):
        return self.Attack(["x"], 1, turn)



class AP(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "APO", 3, 2, x, y)
            color = (255, 69, 0)
            self.color = color

    def display(self, screen):
        pygame.draw.circle(screen, self.color, ((display_width/3.2)+(self.x*blocksize)+50+(
            display_width/40), 50+(display_height/3.529)+(self.y*blocksize)), 50, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        enemy.canATK = False
        return True

    def Maction(self, turn):
        if self.owner == "player1":
            player1Hand.append("MOVEO")
        if self.owner == "player2":
            player2Hand.append("MOVEO")
        return True

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)


class heavyFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "HFO", 9, 1, x, y)
            color = (255, 69, 0)
            self.color = color
            self.M = 0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+100+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        self.moving = True
        return True

    def Maction(self, turn):
        if turn == self.owner:
            self.M += 1
            self.attack += 1
        else:
            self.attack -= self.M
            self.M = 0
        return True

    def atk(self, turn):
        return self.Attack(["cross", "x"], 2, turn)


class lightFighter(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "LFO", 6, 2, x, y)
            color = (255, 69, 0)
            self.color = color
            self.M = 0

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+3), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25), ((display_width/3.2)+(self.x*blocksize)+45+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75),
                      ((display_width/3.2)+(self.x*blocksize)+50+(display_width/40), (display_height/3.529)+(self.y*blocksize)+97), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+75), ((display_width/3.2)+(self.x*blocksize)+55+(display_width/40), (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+75+(display_width/40), (display_height/3.529)+(self.y*blocksize)+25)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        if self.M == 0:
            self.moving = True
        if self.M == 1:
            self.M = 0
        return True

    def atk(self, turn):
        return self.Attack(["cross"], 1, turn)

    def Maction(self, turn):
        self.M = 1
        self.Attack(["nearest"], 1, turn)
        return True


class SP(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "SPO", 1, 5, x, y)
            color = (255, 69, 0)
            self.color = color

    def display(self, screen):
        self.shape = [((display_width/3.2)+(self.x*blocksize)+25+(display_width/40), (display_height/3.529)+(self.y*blocksize)-20), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x *
                                                                                                                                                                                                                                                                                           blocksize)+50, (display_height/3.529)+(self.y*blocksize)+110), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+30), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)-20)]
        pygame.draw.lines(screen, self.color, True, self.shape, 4)
        self.update(screen)

    def ability(self, enemy, turn):
        return True

    def atk(self, turn):
        return self.Attack(["farest"], 1, turn)

    def Maction(self, turn):
        self.M = self.attack
        self.attack = 3
        self.Attack(["farest"], 1, turn)
        self.attack = self.M
        return True


class APT(cards):
    def __init__(self, owner, color, x, y):
        if color == "orange":
            super().__init__(owner, "APTO", 4, 3, x, y)
            color = (255, 69, 0)
            self.color = color

    def display(self, screen):
        self.shapee = [((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)-15, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+25, (display_height/3.529)+(self.y*blocksize)+100),
                       ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+75, (display_height/3.529)+(self.y*blocksize)+100), ((display_width/3.2)+(display_width/40)+(self.x*blocksize)+115, (display_height/3.529)+(self.y*blocksize)+50), ((display_width/3.2)+(self.x*blocksize)+(display_width/40)+75, (display_height/3.529)+(self.y*blocksize))]
        pygame.draw.lines(screen, self.color, True, self.shapee, 3)
        self.update(screen)

    def ability(self, enemy, turn):
        return False
    
    def Maction(self, turn):
        if turn == "player1":
            Min = []
            if len(player1) > 1:
                for i in player1:
                    if i != self:
                        Min = [i]
                        break
            elif len(player1) == 1:
                self.armor += 1
                return True
            for i in player1:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 1
                Min[i].armor += 1
                return True
            elif len(Min) == 1:
                self.armor += 1
                Min[0].armor += 1
                return True
        elif turn == "player2":
            Min = []
            if len(player2) > 1:
                for i in player2:
                    if i != self:
                        Min = [i]
                        break
            elif len(player2) == 1:
                self.armor += 1
                return True
            for i in player2:
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) < abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min = [i]
                if abs(i.BoardX-self.BoardX)+abs(i.BoardY-self.BoardY) == abs(Min[0].BoardX-self.BoardX)+abs(Min[0].BoardY-self.BoardY) and i != self:
                    Min.append(i)
            if len(Min) > 1:
                i = random.randint(0, len(Min)-1)
                self.armor += 1
                Min[i].armor += 1
                return True
            elif len(Min) == 1:
                self.armor += 1
                Min[0].armor += 1
                return True
        return False

    def atk(self, turn):
        return self.Attack(["nearest"], 1, turn)

